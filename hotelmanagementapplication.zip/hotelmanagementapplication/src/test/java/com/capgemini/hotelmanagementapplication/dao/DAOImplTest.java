package com.capgemini.hotelmanagementapplication.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagementapplication.factory.Factory;

class DAOImplTest {
	Dao dao = Factory.getDAOInstance();

	@Test
	@DisplayName("customer login valid")
	void testLogin() {

		assertEquals(true, dao.login("vinod", "Vinod@123"));

	}

	@Test
	@DisplayName("Invalidcustomer login")

	void testLogin1() {

		assertEquals(false, dao.login("vinod", "inod@123"));

	}

	@Test
	@DisplayName("createpassword")
	void testCreatePassword() {
		assertEquals(true, dao.createPassword("vinod1730"));
	}

	@Test
	@DisplayName("Invalid createpassword")
	void testCreatePassword1() {
		assertEquals(false, dao.createPassword("inod1730"));
	}

	@Test
	@DisplayName("valid update password")
	void testUpdatePassword() {
		assertEquals(true, dao.updatePassword("vinod1730", "Vinod@12345"));
	}

	@Test
	@DisplayName("Invalid valid update password")
	void testUpdatePassword1() {
		assertEquals(false, dao.updatePassword("inod1730", "Vinod@12345"));
	}

	@Test
	@DisplayName("Hotel location")
	void testGetHotelLocation() {
		assertNotNull(dao.getHotelLocation("vizag"));
	}

	@Test
	@DisplayName("Invalid Hotel location")
	void testGetHotelLocation1() {
		assertNotNull(dao.getHotelLocation("mumbai"));
	}

	@Test
	@DisplayName("valid customer booking")
	void testCheckCustomerBooking() {
		assertNotNull(dao.checkCustomerBooking("vinod"));
	}

	@Test
	@DisplayName("Invalid valid customer booking")
	void testCheckCustomerBooking1() {
		assertNotNull( dao.checkCustomerBooking("inod"));
	}

	@Test
	@DisplayName("room for booking")
	void testGetRoomForBooking() {
		assertNotNull(dao.getRoomForBooking("vizag", "2"));
	}

	@Test
	@DisplayName("Invalid room for booking")
	void testGetRoomForBooking1() {
		assertNotNull( dao.getRoomForBooking("vizag", "3"));
	}

	@Test
	@DisplayName("check room for booking")
	void testCheckRoomForBooking() {
		assertNotNull(dao.checkRoomForBooking("Single", "2", "vizag"));
	}

	@Test
	@DisplayName("Invalid check room for booking")
	void testCheckRoomForBooking1() {
		assertNotNull( dao.checkRoomForBooking("Triple", "3", "mumbai"));
	}

	@Test
	@DisplayName("Valid Employee login")
	void testEmployeeLoginDetails() {
		assertEquals(true, dao.employeeLoginDetails("chandra", "Chandra@123"));
	}

	@Test
	@DisplayName("Invalid  Employee login")
	void testEmployeeLoginDetails1() {
		assertEquals(false, dao.employeeLoginDetails("chandra", "chandra@123"));
	}

	@Test
	@DisplayName("get customers")
	void testGetCustomers() {
		assertNotNull(dao.getCustomers());
	}

	@Test
	@DisplayName("valid admin login")
	void testAdminLoginDetails() throws FileNotFoundException, IOException {
		assertEquals(true, dao.adminLoginDetails("admin", "Admin@123"));
	}

	@Test
	@DisplayName("Invalid  admin login")
	void testAdminLoginDetails1() throws FileNotFoundException, IOException {
		assertEquals(false, dao.adminLoginDetails("admin", "dmin@123"));
	}

	@Test
	@DisplayName("invalid unique username")
	void testCheckUniqueUsernameForCustomer() {
		assertEquals(true, dao.checkUniqueUsernameForCustomer("vinod"));
	}

	@Test
	@DisplayName("valid unique username")
	void testCheckUniqueUsernameForCustomer1() {
		assertEquals(false, dao.checkUniqueUsernameForCustomer("inod"));
	}

	@Test
	@DisplayName("check location")
	void testCheckLocationForHotel() {
		assertEquals(true, dao.checkLocationForHotel("chennai"));

	}

	@Test
	@DisplayName("Invalid check location")
	void testCheckLocationForHotel1() {
		assertEquals(false, dao.checkLocationForHotel("munnar"));

	}

	@Test
	@DisplayName("invalid hotel unique number")
	void testCheckUniqueHotelNumber() {
		assertEquals(true, dao.checkUniqueHotelNumber("1", "vizag"));
	}

	@Test
	@DisplayName("valid hotel unique number")
	void testCheckUniqueHotelNumber1() {
		assertEquals(false, dao.checkUniqueHotelNumber("3", "vizag"));
	}

	@Test
	@DisplayName("valid delete hotel")
	void testDeleteHotelDetails() {
		assertEquals(true, dao.deleteHotelDetails("2", "chennai"));
	}

	@Test
	@DisplayName("Invalid delete hotel")
	void testDeleteHotelDetails1() {
		assertEquals(false, dao.deleteHotelDetails("3", "chennai"));
	}

	@Test
	@DisplayName("valid update")
	void testUpdateHotelDetails() {
		assertEquals(true, dao.updateHotelDetails("1", "chennai"));
	}

	@Test
	@DisplayName("Invalid update")
	void testUpdateHotelDetails1() {
		assertEquals(false, dao.updateHotelDetails("3", "chennai"));
	}

	@Test
	@DisplayName("Update hotel")
	void testUpdateForHotelDetails() {
		assertEquals(true, dao.updateForHotelDetails("2", "vizag", "Hotel vinod", "hotelvinod@gmail.com", 9493115665l));
	}

	@Test
	@DisplayName("Invalid Update hotel")
	void testUpdateForHotelDetails1() {
		assertEquals(false,
				dao.updateForHotelDetails("3", "mumbai", "Hotel vinod", "hotelvinod@gmail.com", 9493115665l));
	}

	@Test
	@DisplayName("get all hotels")
	void testGetAllHotel() {
		assertNotNull(dao.getAllHotel());

	}

	@Test
	@DisplayName("check hotel details")
	void testCheckRoomDetails() {
		assertNotNull(dao.checkRoomDetails("vizag", "1"));
	}

	@Test
	@DisplayName("Invalid check hotel details")
	void testCheckRoomDetails1() {
		assertNotNull( dao.checkRoomDetails("vizag", "3"));
	}

	@Test
	@DisplayName("valid delete room")
	void testDeleteRoom() {
		assertEquals(true, dao.deleteRoom("chennai", "1", "Single"));
	}

	@Test
	@DisplayName("Invalid  delete room")
	void testDeleteRoom1() {
		assertEquals(false, dao.deleteRoom("chennai", "5", "Single"));
	}

	@Test
	@DisplayName("update room")
	void testUpdateRoom() {
		assertEquals(true, dao.updateRoom("vizag", "1","Grand Chola", "Single", 10000));
	}

	@Test
	@DisplayName("Invalid update room")
	void testUpdateRoom1() {
		assertEquals(false, dao.updateRoom("vizag", "11","Hotel Power", "Single", 10000));
	}

	@Test
	@DisplayName("get all rooms")
	void testGetAllRooms() {
		assertNotNull(dao.getAllRooms());
	}

	@Test
	@DisplayName("Invalid unique username for employee")
	void testCheckUniqueUsernameForEmployee() {
		assertEquals(true, dao.checkUniqueUsernameForEmployee("chandra"));
	}

	@Test
	@DisplayName("valid unique username for employee")
	void testCheckUniqueUsernameForEmployee1() {
		assertEquals(false, dao.checkUniqueUsernameForEmployee("chand"));
	}

	@Test
	@DisplayName("get all employees")
	void testGetAllEmployees() {
		assertNotNull(dao.getAllEmployees());
	}

	@Test
	@DisplayName("Invalid  employee delete")
	void testEmployeeDelete() {
		assertEquals(false, dao.employeeDelete("chand"));
	}

	@Test
	@DisplayName("check employee to update")
	void testCheckEmployeeUpdate() {
		assertEquals(true, dao.checkEmployeeUpdate("chandra"));
	}

	@Test
	@DisplayName("invalid check employee to update")
	void testCheckEmployeeUpdate1() {
		assertEquals(false, dao.checkEmployeeUpdate("chand"));
	}

	@Test
	@DisplayName("update employee")
	void testUpdateEmployee() {
		assertEquals(true, dao.updateEmployee("chandra", "maddea vinod", "maddelavinod@gmail.com", 9493115665l,
				"Chandra@123", 56000));
	}

	@Test
	@DisplayName("guest list")
	void testGetGuestList() {
		assertNotNull(dao.getGuestList("Green View"));
	}

	@Test
	@DisplayName("In validguest list")
	void testGetGuestList1() {
		assertNotNull(dao.getGuestList("hotel pal"));
	}

	@Test
	@DisplayName("Date requried")
	void testGetDateRequried() {
		assertNotNull(dao.getDateRequried(LocalDate.of(2020, 05, 22)));
	}

	@Test
	@DisplayName("Add Customer")
	void testAddDetails() {
		assertEquals(true,
				dao.addDetails("vinod5012", "vinod maddela", "vinodmaddela@gmail.com", 9440388919l, "Maddela@123"));
	}

	@Test
	@DisplayName("Add Hotel")
	void testAddHotelDetails() {

		assertEquals(true, dao.addHotelDetails("Hotel Vinod", "chennai", "5", "hotelvinod@gmail.com", 9701125606l));

	}

	@Test
	@DisplayName("Add Room")
	void testAddRoomInformation() {
		
		assertEquals(true,dao.addRoomInformation("chennai", "Green View", "2", "Double", 20000));
	}

	@Test
	@DisplayName("Add Employee")
	void testAddEmployee() {
		assertEquals(true,dao.addEmployee("chand", "maddela chandra", "maddelachandra@gmail.com", 9494307603l, "Chand@123", 21000));
	}

}
