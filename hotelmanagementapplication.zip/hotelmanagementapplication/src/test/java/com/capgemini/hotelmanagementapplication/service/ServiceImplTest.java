package com.capgemini.hotelmanagementapplication.service;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.dao.Dao;
import com.capgemini.hotelmanagementapplication.factory.Factory;
import com.capgemini.hotelmanagementapplication.validation.InputValidations;

class ServiceImplTest {
	CustomerInformationBean customerinfo = Factory.getCustomerInformationInstance();
	InputValidations inputvalidation = Factory.getInputValidationInstance();
	Dao dao = Factory.getDAOInstance();

	@Test
	@DisplayName("Valid Choice")
	void testChoiceVerify() {
		assertEquals(true, inputvalidation.choiceValidate1("1"));
	}

	@Test
	@DisplayName("InValid Choice")
	void testChoiceVerify1() {
		assertEquals(false, inputvalidation.choiceValidate1("11"));
	}

	@Test
	@DisplayName("Customer Login")
	void testLoginDetails() {
		assertEquals(true, dao.login("vinod", "Vinod@123"));

	}

	@Test
	@DisplayName("Invalid Customer Login")
	void testLoginDetails1() {
		assertEquals(false, dao.login("vinod5046", "Vinod@123"));

	}

	@Test
	@DisplayName("Valid username")
	void testUserName() {
		assertEquals(true, inputvalidation.usernameValidation("vinod"));
	}

	@Test
	@DisplayName("InValid username")
	void testUserName1() {
		assertEquals(false, inputvalidation.usernameValidation("12"));
	}

	@Test
	@DisplayName("Valid name")
	void testNameVerify() {
		assertEquals(true, inputvalidation.nameValidation("vinod Chandra"));
	}

	@Test
	@DisplayName("InValid name")
	void testNameVerify1() {
		assertEquals(false, inputvalidation.nameValidation("vinod Chandra Maddela"));
	}

	@Test
	@DisplayName("Valid Phone number")
	void testPhoneNumber() {
		assertEquals(true, inputvalidation.phonenumberValidation("9493115665"));
	}

	@Test
	@DisplayName("InValid Phone number")
	void testPhoneNumber1() {
		assertEquals(false, inputvalidation.phonenumberValidation("1493115665"));
	}

	@Test
	@DisplayName("Valid mailid")
	void testMailId() {
		assertEquals(true, inputvalidation.mailValidation("vinod@gmail.com"));
	}

	@Test
	@DisplayName("InValid mailid")
	void testMailId1() {
		assertEquals(false, inputvalidation.mailValidation("vinodgmail.com"));
	}

	@Test
	@DisplayName("valid password")
	void testPassword() {
		assertEquals(true, inputvalidation.passwordValidation("Vinod@123"));
	}

	@Test
	@DisplayName("InValid password")
	void testPassword1() {
		assertEquals(false, inputvalidation.passwordValidation("vinod@123"));
	}

	@Test
	@DisplayName("check username for creating password")
	void testCreatePassword() {
		assertEquals(true, dao.createPassword("vinod"));
	}

	@Test
	@DisplayName("check inusername for creating password")
	void testCreatePassword1() {
		assertEquals(false, dao.createPassword("vvinod"));
	}

	@Test
	@DisplayName("Update password")
	void testUpdatePassword() {
		assertEquals(true, dao.updatePassword("vinod", "Vinod1234@"));
	}

	@Test
	@DisplayName("Get Hotel on requried location")
	void testGetHotel() {
		assertNotNull(dao.getHotelLocation("bhimavaram"));
	}

	@Test
	@DisplayName("Get Hotel on requried location")
	void testGetHotel1() {
		assertNotNull(dao.getHotelLocation("chennai"));
	}

	@Test
	@DisplayName("Invalid customer")
	void testCheckBooking() {
		assertNotNull(dao.checkCustomerBooking("vinodm"));
	}

	@Test
	@DisplayName("valid customer")
	void testCheckBooking1() {
		assertNotNull(dao.checkCustomerBooking("vinod"));
	}

	@Test
	@DisplayName("Check rooms")
	void testCheckRooms() {
		assertNotNull(dao.getRoomForBooking("chennai", "2"));
	}

	@Test
	@DisplayName("Check rooms")
	void testCheckRooms1() {
		assertNotNull(dao.getRoomForBooking("chennai", "5"));
	}

	@Test
	@DisplayName("Valid Date")
	void testDateVerify() {
		assertEquals(true, inputvalidation.dateValidation("2020-05-20"));
	}

	@Test
	@DisplayName("InValid Date")
	void testDateVerify1() {
		assertEquals(false, inputvalidation.dateValidation("2020-5-20"));
	}

	@Test
	@DisplayName("Employee login")
	void testEmployeeLoginDetails() {
		assertEquals(true, dao.employeeLoginDetails("chandra", "Chandra@123"));
	}

	@Test
	@DisplayName("Invalid Employee login")
	void testEmployeeLoginDetails1() {
		assertEquals(false, dao.employeeLoginDetails("chandr", "Chandra@123"));
	}

	@Test
	void testGetAllCustomers() {
		assertNotNull(dao.getCustomers());
	}

	@Test
	@DisplayName("Unique username")
	void testCheckUserNameForRegistration() {
		assertEquals(true, dao.checkUniqueUsernameForCustomer("vinod"));
	}

	@Test
	@DisplayName("Unique username")
	void testCheckUserNameForRegistration1() {
		assertEquals(false, dao.checkUniqueUsernameForCustomer("vinod1"));
	}

	@Test
	@DisplayName("Valid admin")
	void testAdminLoginDetails() throws FileNotFoundException, IOException {
		assertEquals(true, dao.adminLoginDetails("admin", "Admin@123"));
	}

	@Test
	@DisplayName("Valid admin")
	void testAdminLoginDetails1() throws FileNotFoundException, IOException {
		assertEquals(false, dao.adminLoginDetails("admin", "admin@123"));
	}

	@Test
	@DisplayName("valid Location")
	void testCheckLocation() {
		assertEquals(true, dao.checkLocationForHotel("vizag"));
	}

	@Test
	@DisplayName("Invalid Location")
	void testCheckLocation1() {
		assertEquals(false, dao.checkLocationForHotel("mumbai"));
	}

	@Test
	@DisplayName("existing hotelnumber")
	void testCheckHotelNumber1() {
		assertEquals(false, dao.checkUniqueHotelNumber("vizag", "2"));
	}

	@Test
	@DisplayName("HotelNumber")
	void testHotelNumberVerify() {
		assertEquals(true, inputvalidation.hotelNumbervalidation("1"));
	}

	@Test
	@DisplayName("HotelNumber")
	void testHotelNumberVerify1() {
		assertEquals(false, inputvalidation.hotelNumbervalidation("100"));
	}

	@Test
	@DisplayName("Delete hotel")
	void testDeleteHotel() {
		assertEquals(true, dao.deleteHotelDetails("2", "chennai"));
	}

	@Test
	@DisplayName("Update Hotel")
	void testUpdateHotel() {
		assertEquals(true, dao.updateHotelDetails("2", "vizag"));
	}

	@Test
	@DisplayName("Update Hotel Details")
	void testUpdateForHotel() {
		assertEquals(true, dao.updateForHotelDetails("2", "vizag", "Hotel Vinod", "hotelvinod@gmail.com", 9493115665l));
	}

	@Test
	@DisplayName("all hotels")
	void testGetAllHotels() {
		assertNotNull(dao.getAllHotel());
	}

	@Test
	void testCheckRoom() {
		assertNotNull(dao.checkRoomDetails("vizag", "2"));
	}

	@Test
	@DisplayName("Price Validation")
	void testPriceVerify() {
		assertEquals(true, inputvalidation.priceValidation("10000"));
	}

	@Test
	@DisplayName("Price Validation")
	void testPriceVerify1() {
		assertEquals(false, inputvalidation.priceValidation("100"));
	}

	@Test
	@DisplayName("Delete Room")
	void testDeleteRoom() {
		assertEquals(true, dao.deleteRoom("vizag", "2", "Double"));
	}

	@Test
	@DisplayName("Invalid Delete Room")
	void testDeleteRoom1() {
		assertEquals(false, dao.deleteRoom("vizag", "2", "Triple"));
	}

	@Test
	@DisplayName("Update Room")
	void testUpdateRoom() {
		assertEquals(true, dao.updateRoom("chennai", "2","Green View", "Double", 20000));
	}

	@Test
	void testGetAllRoom() {
		assertNotNull(dao.getAllRooms());
	}

	@Test
	void testCheckUserNameForEmployee() {
		assertEquals(false, dao.checkUniqueUsernameForEmployee("vinid"));
	}

	@Test
	void testCheckUserNameForEmployee1() {
		assertEquals(true, dao.checkUniqueUsernameForEmployee("chandra"));
	}

	@Test
	void testSalaryVerify() {
		assertEquals(true, inputvalidation.salaryValidation("15000"));
	}

	@Test
	void testSalaryVerify1() {
		assertEquals(false, inputvalidation.salaryValidation("abd"));
	}

	@Test
	void testGetAllEmployees() {
		assertNotNull(dao.getAllEmployees());
	}

	@Test
	void testEmployeeDelete() {
		assertEquals(false, dao.employeeDelete("chand"));
	}

	@Test
	void testCheckEmployeeUpdate() {
		assertEquals(true, dao.checkEmployeeUpdate("chandra"));
	}

	@Test
	void testUpdateEmployee() {
		assertEquals(true, dao.updateEmployee("chandra", "maddela vinod", "maddelavinod@gmail.com", 9493115665l,
				"Chandra@123", 25000));
	}

	@Test
	void testGetGuestList() {
		assertNotNull(dao.getGuestList("Green View"));
	}

	@Test
	void testGetGuestList1() {
		assertNotNull(dao.getGuestList("Hotel Palasa"));
	}

	@Test
	void testGetDateRequried() {
		assertNotNull(dao.getDateRequried(LocalDate.of(2020, 05, 10)));
	}

	@Test

	void testGetDateRequried1() {
		assertNotNull( dao.getDateRequried(LocalDate.of(2020, 05, 06)));
	}

}
