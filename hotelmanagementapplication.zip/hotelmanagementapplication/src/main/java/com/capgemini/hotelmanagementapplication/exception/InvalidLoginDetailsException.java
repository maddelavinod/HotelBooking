package com.capgemini.hotelmanagementapplication.exception;

/**
 * This is a custom exception created by the programmer when he created his own
 * exceptions
 *
 */

public class InvalidLoginDetailsException extends RuntimeException {

	private static final long serialVersionUID = 7355113904556217047L;
	String message = "Invalid login details please try again";

	/**
	 * this method return message when ever exception called
	 * 
	 * @return message
	 */

	public String requriedMessage() {
		return message;

	}

}
