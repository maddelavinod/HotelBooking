package com.capgemini.hotelmanagementapplication.bean;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 
 * This Is a Bean Class Which Contains BookingInformation Which Contains Private
 * Variables
 * 
 * There Are Getter And Setter Methods TO Get And Set The Variables
 *
 */

public class BookingInformationBean implements Serializable {

	private static final long serialVersionUID = -2331361021564840093L;

	private String bookingUserName;

	private String bookingName;

	private Long bookingNumber;

	private String bookingHotel;

	private String bookingRoomType;

	private double bookingPrice;

	private LocalDate bookingDate;

	private LocalDate chechInDate;

	private LocalDate checkOutDate;

	private String paymentMode;

	public BookingInformationBean() {

	}

	/**
	 * 
	 * This Method Is Used To Get Booking userName
	 * 
	 * @return bookingusername
	 */

	public String getBookingUserName() {
		return bookingUserName;
	}

	/**
	 * This Method Is Used To Set Booking userName
	 * 
	 * @param bookingusername
	 */

	public void setBookingUserName(String bookingUserName) {
		this.bookingUserName = bookingUserName;
	}

	/**
	 * 
	 * This Method Is Used To Get BookingName
	 * 
	 * @return bookingname
	 */

	public String getBookingName() {
		return bookingName;
	}

	/**
	 * This Method Is Used To Set Booking userName
	 * 
	 * @param bookingname
	 */
	public void setBookingName(String bookingName) {
		this.bookingName = bookingName;
	}

	/**
	 * 
	 * This Method Is Used To Get BookingNumber
	 * 
	 * @return bookingnumber
	 */

	public Long getBookingNumber() {
		return bookingNumber;
	}

	/**
	 * This Method Is Used To Set Booking userNumber
	 * 
	 * @param bookingusernumber
	 */

	public void setBookingNumber(Long bookingNumber) {
		this.bookingNumber = bookingNumber;
	}

	/**
	 * 
	 * This Method Is Used To Get BookingHotel
	 * 
	 * @return bookingHotel
	 */

	public String getBookingHotel() {
		return bookingHotel;
	}

	/**
	 * This Method Is Used To Set Booking userHotel
	 * 
	 * @param bookingHotel
	 */
	public void setBookingHotel(String bookingHotel) {
		this.bookingHotel = bookingHotel;
	}

	/**
	 * 
	 * This Method Is Used To Get Bookingroomtype
	 * 
	 * @return bookingroomtype
	 */

	public String getBookingRoomType() {
		return bookingRoomType;
	}

	/**
	 * This Method Is Used To Set Booking roomtype
	 * 
	 * @param bookingroomtype
	 */

	public void setBookingRoomType(String bookingRoomType) {
		this.bookingRoomType = bookingRoomType;
	}

	/**
	 * 
	 * This Method Is Used To Get BookingPrice
	 * 
	 * @return bookingname
	 */

	public double getBookingPrice() {
		return bookingPrice;
	}

	public void setBookingPrice(double price) {
		this.bookingPrice = price;
	}

	/**
	 * 
	 * This Method Is Used To Get Bookingdate
	 * 
	 * @return bookingname
	 */

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	/**
	 * 
	 * This Method Is Used To Get checkin date
	 * 
	 * @return checkindate
	 */

	public LocalDate getChechInDate() {
		return chechInDate;
	}

	public void setChechInDate(LocalDate chechInDate) {
		this.chechInDate = chechInDate;
	}

	/**
	 * 
	 * This Method Is Used To Get checkoutdate
	 * 
	 * @return checkoutdate
	 */

	public LocalDate getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(LocalDate checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	/**
	 * 
	 * This Method Is Used To Get paymentmode
	 * 
	 * @return paymentmode
	 */

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bookingDate == null) ? 0 : bookingDate.hashCode());
		result = prime * result + ((bookingHotel == null) ? 0 : bookingHotel.hashCode());
		result = prime * result + ((bookingName == null) ? 0 : bookingName.hashCode());
		result = prime * result + ((bookingNumber == null) ? 0 : bookingNumber.hashCode());
		long temp;
		temp = Double.doubleToLongBits(bookingPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((bookingRoomType == null) ? 0 : bookingRoomType.hashCode());
		result = prime * result + ((bookingUserName == null) ? 0 : bookingUserName.hashCode());
		result = prime * result + ((chechInDate == null) ? 0 : chechInDate.hashCode());
		result = prime * result + ((checkOutDate == null) ? 0 : checkOutDate.hashCode());
		result = prime * result + ((paymentMode == null) ? 0 : paymentMode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingInformationBean other = (BookingInformationBean) obj;
		if (bookingDate == null) {
			if (other.bookingDate != null)
				return false;
		} else if (!bookingDate.equals(other.bookingDate))
			return false;
		if (bookingHotel == null) {
			if (other.bookingHotel != null)
				return false;
		} else if (!bookingHotel.equals(other.bookingHotel))
			return false;
		if (bookingName == null) {
			if (other.bookingName != null)
				return false;
		} else if (!bookingName.equals(other.bookingName))
			return false;
		if (bookingNumber == null) {
			if (other.bookingNumber != null)
				return false;
		} else if (!bookingNumber.equals(other.bookingNumber))
			return false;
		if (Double.doubleToLongBits(bookingPrice) != Double.doubleToLongBits(other.bookingPrice))
			return false;
		if (bookingRoomType == null) {
			if (other.bookingRoomType != null)
				return false;
		} else if (!bookingRoomType.equals(other.bookingRoomType))
			return false;
		if (bookingUserName == null) {
			if (other.bookingUserName != null)
				return false;
		} else if (!bookingUserName.equals(other.bookingUserName))
			return false;
		if (chechInDate == null) {
			if (other.chechInDate != null)
				return false;
		} else if (!chechInDate.equals(other.chechInDate))
			return false;
		if (checkOutDate == null) {
			if (other.checkOutDate != null)
				return false;
		} else if (!checkOutDate.equals(other.checkOutDate))
			return false;
		if (paymentMode == null) {
			if (other.paymentMode != null)
				return false;
		} else if (!paymentMode.equals(other.paymentMode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return " bookingUserName=" + bookingUserName + "\n bookingname=" + bookingName + "\n bookingnumber="
				+ bookingNumber + "\n bookinghotel=" + bookingHotel + " \n bookingroomtype=" + bookingRoomType
				+ "\n bookingprice=" + bookingPrice + "\n bookingdate=" + bookingDate + "\n chechindate=" + chechInDate
				+ "\n checkoutdate=" + checkOutDate + "\n paymentMode=" + paymentMode + "\n";
	}

}
