package com.capgemini.hotelmanagementapplication.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;
import com.capgemini.hotelmanagementapplication.dao.Dao;
import com.capgemini.hotelmanagementapplication.factory.Factory;
import com.capgemini.hotelmanagementapplication.validation.InputValidations;

public class ServiceImpl implements Service {

	InputValidations inputvalidation = Factory.getInputValidationInstance();

	Dao dao = Factory.getDAOInstance();

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */

	@Override
	public boolean choiceVerify(String choice) {
		return (inputvalidation.choiceValidate1(choice));

	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */

	@Override
	public boolean loginDetails(String userName, String password) {
		return dao.login(userName, password);

	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */
	@Override
	public boolean userName(String userName) {

		return (inputvalidation.usernameValidation(userName));

	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */

	@Override
	public boolean nameVerify(String name) {

		return (inputvalidation.nameValidation(name));

	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */

	@Override
	public boolean phoneNumber(String phoneNumber) {
		return (inputvalidation.phonenumberValidation(phoneNumber));
	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */
	@Override
	public boolean mailId(String mail) {
		return (inputvalidation.mailValidation(mail));
	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */
	@Override
	public boolean password(String password) {
		return (inputvalidation.passwordValidation(password));
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean addCustomer(String userName, String name, String mail, long phoneNumber, String password) {
		return dao.addDetails(userName, name, mail, phoneNumber, password);

	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean createPassword(String userName) {
		return dao.createPassword(userName);

	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean updatePassword(String userName, String password) {

		return dao.updatePassword(userName, password);

	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<HotelInformationBean> getHotel(String location) {

		return dao.getHotelLocation(location);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<BookingInformationBean> checkBooking(String userName) {

		return dao.checkCustomerBooking(userName);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<RoomInformationBean> checkRooms(String location, String hotelNumber) {

		return dao.getRoomForBooking(location, hotelNumber);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<RoomInformationBean> roomForBooking(String roomTpye, String hotelNumber, String location) {

		return dao.checkRoomForBooking(roomTpye, hotelNumber, location);
	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */
	@Override
	public boolean dateVerify(String date) {
		return (inputvalidation.dateValidation(date));
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean bookingDetails(BookingInformationBean bookinginfo) {

		if (bookinginfo == null) {
			return false;
		}
		return dao.addBooking(bookinginfo);

	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean employeeLoginDetails(String userName, String password) {

		return dao.employeeLoginDetails(userName, password);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<CustomerInformationBean> getAllCustomers() {

		return dao.getCustomers();
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean checkUserNameForRegistration(String userName) {

		return dao.checkUniqueUsernameForCustomer(userName);

	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean adminLoginDetails(String userName, String password) throws IOException {

		return dao.adminLoginDetails(userName, password);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */

	@Override
	public boolean checkLocation(String location) {

		return dao.checkLocationForHotel(location);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean checkHotelNumber(String hotelNumber, String location) {

		return dao.checkUniqueHotelNumber(hotelNumber, location);
	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */
	@Override
	public boolean hotelNumberVerify(String hotelNumber) {
		return (inputvalidation.hotelNumbervalidation(hotelNumber));
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean addHotel(String hotelName, String location, String hotelNumber, String mail, long phoneNumber) {

		return dao.addHotelDetails(hotelName, location, hotelNumber, mail, phoneNumber);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean deleteHotel(String hotelNumber, String location) {

		return dao.deleteHotelDetails(hotelNumber, location);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean updateHotel(String hotelNumber, String location) {

		return dao.updateHotelDetails(hotelNumber, location);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean updateForHotel(String hotelNumber, String location, String hotelName, String mail,
			long phoneNumber) {

		return dao.updateForHotelDetails(hotelNumber, location, hotelName, mail, phoneNumber);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<HotelInformationBean> getAllHotels() {

		return dao.getAllHotel();
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<HotelInformationBean> checkRoom(String location, String hotelNumber) {

		return dao.checkRoomDetails(location, hotelNumber);
	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */
	@Override
	public boolean priceVerify(String price) {
		return (inputvalidation.priceValidation(price));
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean addRoomInformation(String location, String hotelName, String hotelNumber, String roomType,
			double price) {

		return dao.addRoomInformation(location, hotelName, hotelNumber, roomType, price);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean deleteRoom(String location, String hotelNumber, String roomType) {

		return dao.deleteRoom(location, hotelNumber, roomType);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean updateRoom(String location, String hotelNumber, String hotelName,String roomType, double price) {

		return dao.updateRoom(location, hotelNumber,hotelName, roomType, price);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<RoomInformationBean> getAllRoom() {

		return dao.getAllRooms();
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean checkUserNameForEmployee(String userName) {

		return dao.checkUniqueUsernameForEmployee(userName);
	}

	/**
	 * This method acts like a bridge between controller and validation
	 * 
	 * @return true
	 */

	@Override
	public boolean salaryVerify(String salary) {
		return (inputvalidation.salaryValidation(salary));
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */

	@Override
	public boolean addEmployee(String userName, String name, String mail, long phoneNumber, String password,
			int salary) {

		return dao.addEmployee(userName, name, mail, phoneNumber, password, salary);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<EmployeeInformationBean> getAllEmployees() {

		return dao.getAllEmployees();
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */

	@Override
	public boolean employeeDelete(String userName) {

		return dao.employeeDelete(userName);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean checkEmployeeUpdate(String userName) {

		return dao.checkEmployeeUpdate(userName);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return true
	 */
	@Override
	public boolean updateEmployee(String userName, String name, String mail, long phoneNumber, String password,
			int salary) {

		return dao.updateEmployee(userName, name, mail, phoneNumber, password, salary);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<BookingInformationBean> getGuestList(String hotelName) {

		return dao.getGuestList(hotelName);
	}

	/**
	 * This method acts like a bridge between controller and dao
	 * 
	 * @return list
	 */
	@Override
	public List<BookingInformationBean> getDateRequried(LocalDate date) {

		return dao.getDateRequried(date);
	}

}
