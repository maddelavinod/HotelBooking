package com.capgemini.hotelmanagementapplication.bean;

import java.io.Serializable;

/**
 * This is a bean class contains Admin Information Which has Private Variable
 * 
 * There are Public Getters And Setters To use these Variable
 *
 */

public class AdminInformationBean implements Serializable {

	private static final long serialVersionUID = 1637480320611930565L;

	private String userName;

	private String password;

	public AdminInformationBean() {

	}

	/**
	 * This Method Is Used Get Admin User Name
	 * 
	 * 
	 * @return username
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * 
	 * This Method Is Used To Set Admin UserName
	 * 
	 * @param username
	 */

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * 
	 * This Methos Is Used To Get Admin Password
	 * 
	 * @return password
	 */

	public String getPassword() {
		return password;
	}

	/**
	 * 
	 * This Method Is Used To set Admin Password
	 * 
	 * @param password
	 */

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AdminInformationBean other = (AdminInformationBean) obj;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}
}
