package com.capgemini.hotelmanagementapplication.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.factory.Factory;

/**
 * This class contains the data of hotel who added to application
 * 
 * @author vinod
 *
 */
public class HotelInformationRepository {
	static List<HotelInformationBean> hotellist = new ArrayList<HotelInformationBean>();

	public List<HotelInformationBean> getHotelInformationList() {

		HotelInformationBean hotelinformation = Factory.getHotelInformationInstance();
		hotelinformation.setHotelNumber("1");
		hotelinformation.setHotelName("Royal Palace");
		hotelinformation.setLocation("chennai");
		hotelinformation.setMailId("Royalpalace@gmail.com");
		hotelinformation.setPhoneNumber(9999955555l);

		HotelInformationBean hotelinformation1 = Factory.getHotelInformationInstance();
		hotelinformation1.setHotelNumber("2");
		hotelinformation1.setHotelName("Green View");
		hotelinformation1.setLocation("chennai");
		hotelinformation1.setMailId("greenview@gmail.com");
		hotelinformation1.setPhoneNumber(9569955555l);

		HotelInformationBean hotelinformation3 = Factory.getHotelInformationInstance();
		hotelinformation3.setHotelNumber("1");
		hotelinformation3.setHotelName("Grand Chola");
		hotelinformation3.setLocation("vizag");
		hotelinformation3.setMailId("Grandchola@gamil.com");
		hotelinformation3.setPhoneNumber(7878784554l);

		HotelInformationBean hotelinformation4 = Factory.getHotelInformationInstance();
		hotelinformation4.setHotelNumber("2");
		hotelinformation4.setHotelName("Hotel Palasa");
		hotelinformation4.setLocation("vizag");
		hotelinformation4.setMailId("palasa@gamil.com");
		hotelinformation4.setPhoneNumber(9856784554l);

		hotellist.add(hotelinformation);
		hotellist.add(hotelinformation1);
		hotellist.add(hotelinformation3);
		hotellist.add(hotelinformation4);

		return hotellist;

	}

}
