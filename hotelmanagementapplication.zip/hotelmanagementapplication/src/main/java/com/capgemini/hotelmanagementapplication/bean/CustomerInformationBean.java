package com.capgemini.hotelmanagementapplication.bean;

import java.io.Serializable;

/**
 * 
 * This Is a Bean Class Which Contains CustomerInformation Which Contains
 * Private Variables
 * 
 * There Are Getter And Setter Methods TO Get And Set The Variables
 *
 */

public class CustomerInformationBean implements Serializable {

	private static final long serialVersionUID = -6156217986625577327L;

	private String userName;

	private String name;

	private long phoneNumber;

	private String mailId;

	private String password;

	public CustomerInformationBean() {

	}

	/**
	 * This Method Is Used To Get UserName
	 * 
	 * @return username
	 */

	public String getUserName() {
		return userName;
	}

	/**
	 * This Method Is Used To Get UserName
	 * 
	 * @param userName
	 */

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * This Method Is Used To Get Name
	 * 
	 * @return getname
	 */

	public String getName() {
		return name;
	}

	/**
	 * This Method Is Used To Set Name
	 * 
	 * @param Name
	 */

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * This Method Is Used To Get PhoneNumber
	 * 
	 * @return phonenumber
	 */

	public long getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * This Method Is Used To Set Phonenumber
	 * 
	 * @param phoneNumber
	 */

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * This Method Is Used To Get MailId
	 * 
	 * @return mailid
	 */

	public String getMailId() {
		return mailId;
	}

	/**
	 * This Method Is Used To Set MailId
	 * 
	 * @param MailId
	 */

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	/**
	 * This Method Is Used To Get Password
	 * 
	 * @return password
	 */

	public String getPassword() {
		return password;
	}

	/**
	 * This Method Is Used To Set Password
	 * 
	 * @param password
	 */

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mailId == null) ? 0 : mailId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + (int) (phoneNumber ^ (phoneNumber >>> 32));
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerInformationBean other = (CustomerInformationBean) obj;
		if (mailId == null) {
			if (other.mailId != null)
				return false;
		} else if (!mailId.equals(other.mailId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (phoneNumber != other.phoneNumber)
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return " Name=" + name + "\n PhoneNumber=" + phoneNumber + "\n MailId=" + mailId + "\n";
	}

}
