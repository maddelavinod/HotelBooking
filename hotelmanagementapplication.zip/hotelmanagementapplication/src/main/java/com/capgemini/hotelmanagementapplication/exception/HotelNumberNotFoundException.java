package com.capgemini.hotelmanagementapplication.exception;

/**
 * This is a custom exception created by the programmer when he created his own
 * exceptions
 *
 */

public class HotelNumberNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 2855665228050132120L;
	String message = "Given Hotelnumber not found please check and try again ";

	/**
	 * this method return message when ever exception called
	 * 
	 * @return message
	 */

	public String requriedMessage() {
		return message;

	}

}
