package com.capgemini.hotelmanagementapplication.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * Implementation of Inputvalidation Interface and its abstract method
 * 
 *
 */
public class InputValidationImpl implements InputValidations {

	Pattern pattern = null;
	Matcher matcher = null;

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param choice
	 */

	@Override
	public boolean choiceValidate1(String choice) {

		pattern = Pattern.compile("[1-8]");
		matcher = pattern.matcher(choice);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param username
	 */

	@Override
	public boolean usernameValidation(String username) {

		String regex = "^[0-a-z9_-]{3,14}$";

		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		matcher = pattern.matcher(username);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param name
	 */

	@Override
	public boolean nameValidation(String name) {
		String regex = "[a-z][A-z]*+\\s[a-z][A-z]*+";

		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		matcher = pattern.matcher(name);
		return (matcher.matches());

	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param Contactnumber
	 */

	@Override
	public boolean phonenumberValidation(String Contactnumber) {

		pattern = Pattern.compile("^[6789]{1}\\d{9}$");
		matcher = pattern.matcher(Contactnumber);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param mail
	 */

	@Override
	public boolean mailValidation(String mail) {

		pattern = Pattern.compile(
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		matcher = pattern.matcher(mail);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param password
	 */

	@Override
	public boolean passwordValidation(String password) {
		pattern = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})");
		matcher = pattern.matcher(password);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param date
	 */

	@Override
	public boolean dateValidation(String date) {
		pattern = Pattern.compile("[0-9]{4}-(0[1-9]|1[0-2])-(3[0-1]|[1-2][0-9]|0[0-9])");
		matcher = pattern.matcher(date);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param hotelnumbervakidation
	 */

	@Override
	public boolean hotelNumbervalidation(String hotelNumber) {
		pattern = Pattern.compile("\\d{1,2}");
		matcher = pattern.matcher(hotelNumber);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param price
	 */

	@Override
	public boolean priceValidation(String price) {
		pattern = Pattern.compile("\\d{4,5}");
		matcher = pattern.matcher(price);
		return (matcher.matches());
	}

	/**
	 * This Method will check whether the given string is matched or not
	 * 
	 * @return true when matches
	 * 
	 * @return false when not matches
	 * 
	 * @param salary
	 */
	@Override
	public boolean salaryValidation(String salary) {
		pattern = Pattern.compile("\\d{5,6}");
		matcher = pattern.matcher(salary);
		return (matcher.matches());
	}

}
