package com.capgemini.hotelmanagementapplication.exception;

/**
 * This is a custom exception created by the programmer when he created his own
 * exceptions
 *
 */

public class BookingNotDoneException extends RuntimeException {

	private static final long serialVersionUID = -7071164029622860436L;
	String message = "Booking not done ";

	/**
	 * this method return message when ever exception called
	 * 
	 * @return message
	 */

	public String requriedMessage() {
		return message;

	}

}
