package com.capgemini.hotelmanagementapplication.validation;

/**
 * This is an Interface of input validation which contains abstract method
 * 
 * 
 * @ return boolean
 *
 */
public interface InputValidations {

	public boolean choiceValidate1(String choice);

	public boolean usernameValidation(String username);

	public boolean nameValidation(String name);

	public boolean phonenumberValidation(String Contactnumber);

	public boolean mailValidation(String mail);

	public boolean passwordValidation(String password);

	public boolean dateValidation(String date);

	public boolean hotelNumbervalidation(String hotelNumber);

	public boolean priceValidation(String price);

	public boolean salaryValidation(String salary);

}
