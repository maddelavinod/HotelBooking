package com.capgemini.hotelmanagementapplication.controller;

import java.time.LocalDate;

import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;
import com.capgemini.hotelmanagementapplication.exception.BookingNotDoneException;
import com.capgemini.hotelmanagementapplication.exception.HotelNumberNotFoundException;
import com.capgemini.hotelmanagementapplication.exception.InvalidLoginDetailsException;
import com.capgemini.hotelmanagementapplication.exception.RegistrationFailedException;
import com.capgemini.hotelmanagementapplication.exception.RoomNotFoundException;
import com.capgemini.hotelmanagementapplication.factory.Factory;
import com.capgemini.hotelmanagementapplication.service.Service;

/**
 * This class is a controller of customer module.
 * 
 * it will show the operations that can access by customer
 * 
 * @author vinod
 *
 */

public class CustomerController {

	static Scanner scanner = new Scanner(System.in);

	static final Logger log = Logger.getLogger(CustomerController.class);

	private CustomerController() {

	}

	/**
	 * This method will show the operations that customer can perform he can book
	 * hotel and check his booking status and he can update his password
	 * 
	 * If he is a new customer he can register into the application and access all
	 * the above oprations
	 * 
	 */

	public static void operateCustomer() {

		CustomerInformationBean customerinformation = Factory.getCustomerInformationInstance();

		Service service = Factory.getServiceInstance();
		log.info("Welcome TO  Customer Module");
		log.info("Please Select the choice");

		L: do {
			log.info("1.Login(*If you are an existing coustmer* )");
			log.info("2.Register(*If you are new coustmer)");
			log.info("3.Forgot password");
			log.info("4.Exit to Home Page");
			log.info("Enter your choice 1 or 2 or 3 or 4");
			String choice1 = scanner.nextLine();
			while (!service.choiceVerify(choice1)) {
				log.error("Enter valid choice 1 or 2 or 3 or 4");
				choice1 = scanner.nextLine();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {

			case 1:
				log.info(
						"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
				String userName = scanner.nextLine();
				while (!service.userName(userName)) {

					log.error(
							"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
					userName = scanner.nextLine();

				}
				log.info(
						"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
								+ "and specialcharacter(6-20)");
				String password = scanner.nextLine();
				while (!service.password(password)) {
					log.error(
							"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
									+ "and specialcharacter(6-20)");
					password = scanner.nextLine();
				}
				boolean add = service.loginDetails(userName, password);
				try {
					if (add) {
						log.info("login sucessfull");
						customerHotel(userName);
					} else {
						throw new InvalidLoginDetailsException();
					}
				} catch (InvalidLoginDetailsException exception) {
					log.error(exception.requriedMessage());
				}
				break;
			case 2:

				log.info("Enter your details to register");
				log.info(
						"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
				userName = scanner.nextLine();
				while (service.checkUserNameForRegistration(userName)) {
					log.error("username already exists please try new username");
					userName = scanner.nextLine();
				}
				while (!service.userName(userName)) {

					log.error(
							"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
					userName = scanner.nextLine();

				}

				log.info("Enter your name like firstname and lastname (should be only letters)");
				String name = scanner.nextLine();

				while (!service.nameVerify(name)) {
					log.error("Enter your name like firstname and lastname (should be only letters)");
					name = scanner.nextLine();

				}

				log.info("Enter mailid (abc@abc.abc)");
				String mail = scanner.nextLine();
				while (!service.mailId(mail)) {

					log.error("Enter mailid (abc@abc.abc)");
					mail = scanner.nextLine();

				}
				log.info("Enter your phone number(It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
				String phoneNumber = scanner.nextLine();
				while (!service.phoneNumber(phoneNumber)) {
					log.error("Enter your phone number(It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
					phoneNumber = scanner.nextLine();

				}
				long phoneNumbers = Long.parseLong(phoneNumber);
				log.info(
						"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
								+ "and specialcharacter(6-20)");
				password = scanner.nextLine();
				while (!service.password(password)) {
					log.error(
							"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
									+ "and specialcharacter(6-20)");
					password = scanner.nextLine();

				}

				customerinformation.setUserName(userName);
				customerinformation.setName(name);
				customerinformation.setMailId(mail);
				customerinformation.setPhoneNumber(phoneNumbers);
				customerinformation.setPassword(password);

				boolean add1 = service.addCustomer(userName, name, mail, phoneNumbers, password);
				try {
					if (add1) {
						log.info("Registration Sucessfull");
					} else {
						throw new RegistrationFailedException();
					}
				} catch (RegistrationFailedException exception1) {
					log.error(exception1.requriedMessage());
				}

				break;
			case 3:
				log.info("Enter your username to update password");
				userName = scanner.nextLine();
				boolean add2 = service.createPassword(userName);
				if (add2) {
					log.info("UserName found");
					log.info("Enter your password");
					password = scanner.nextLine();
					while (!service.password(password)) {
						log.error(
								"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
										+ "and specialcharacter(6-20)");
						password = scanner.nextLine();
					}
					boolean add3 = service.updatePassword(userName, password);
					if (add3) {
						log.info("Password updated");
					} else {
						log.error("password update unsucessfull");
					}

				} else {
					log.error("UserName not found please check and try again");
				}
				break;
			case 4:
				break L;
			default:
				log.info("Enter valid choice 1 or 2 or 3 or 4");
				break;

			}

		} while (true);

	}

	/**
	 * This method will appear when the customer login to his account
	 * 
	 * customer can book a hotel or he can check his status after login
	 * 
	 * @param username
	 */

	public static void customerHotel(String userName) {
		Service service = Factory.getServiceInstance();
		K: do {
			log.info("Please select your operation");
			log.info("1.Booking Hotel");
			log.info("2.Booking Status");
			log.info("3.logout");
			log.info("Please enter your choice (1 or 2 or 3)");
			String choice1 = scanner.nextLine();
			while (!service.choiceVerify(choice1)) {
				log.error("Please enter valid choice (1 or 2 or 3)");
				choice1 = scanner.nextLine();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {
			case 1:
				checkLocation(userName);
				break;
			case 2:
				List<BookingInformationBean> list = service.checkBooking(userName);
				try {
					if (list.isEmpty()) {
						throw new BookingNotDoneException();
					} else {
						for (BookingInformationBean bookinginfo : list) {

							log.info(bookinginfo);
						}
					}
				} catch (BookingNotDoneException exception) {
					log.error(exception.requriedMessage());
				}
				break;
			case 3:
				break K;
			default:
				log.info("Please enter valid choice (1 or 2 or 3)");
				break;
			}

		} while (true);
	}

	/**
	 * This method will show the locations that customer can choose there requried
	 * location and can move further to book there room ina particular hotel
	 * 
	 * @param username
	 */
	public static void checkLocation(String userName) {
		Service service = Factory.getServiceInstance();
		K: do {
			log.info("Please select location ");
			log.info("1.chennai");
			log.info("2.vizag");
			log.info("3.back");
			log.info("Enter your choice 1 or 2 or 3");
			String choice1 = scanner.nextLine();
			while (!service.choiceVerify(choice1)) {
				log.error("Enter valid choice 1 or 2 or 3");
				choice1 = scanner.nextLine();
			}
			int choice = Integer.parseInt(choice1);
			switch (choice) {
			case 1:
				List<HotelInformationBean> list1 = service.getHotel("chennai");
				if (list1.isEmpty()) {
					log.error("Location not available");
				} else {
					checkHotel(list1, userName, "chennai");
				}

				break;
			case 2:
				List<HotelInformationBean> list2 = service.getHotel("vizag");
				if (list2.isEmpty()) {
					log.error("location not available");
				} else {
					checkHotel(list2, userName, "vizag");
				}
				break;
			case 3:
				break K;
			default:
				log.info("Enter valid choice 1 or 2 or 3");
				break;

			}
		} while (true);
	}

	/**
	 * After selecting location they will enter into this method this method will
	 * show the list of hotels present the selected location
	 * 
	 * @param hotellist
	 * @param username
	 * @param location
	 * @return
	 */

	public static List<HotelInformationBean> checkHotel(List<HotelInformationBean> hotellist, String userName,
			String location) {

		Service service = Factory.getServiceInstance();

		log.info("List of Hotels in " + location);
		for (HotelInformationBean hotelinfo : hotellist) {

			log.info(hotelinfo.getHotelNumber() + "....." + hotelinfo.getHotelName());

		}

		log.info("Enter hotel number");
		String hotelNumber = scanner.nextLine();
		String hotelName = null;
		List<RoomInformationBean> list1 = service.checkRooms(location, hotelNumber);
		for (HotelInformationBean hotelinfo : hotellist) {
			hotelName = hotelinfo.getHotelName();
		}
		try {
			if (list1.isEmpty()) {
				throw new HotelNumberNotFoundException();
			} else {
				checkRooms(userName, list1, hotelNumber, location, hotelName);
			}
		} catch (HotelNumberNotFoundException exception) {
			log.error(exception.requriedMessage());
		}

		return hotellist;

	}

	/**
	 * they will move into this method when they selected there hotel
	 * 
	 * This method will show the rooms present in the selected hotels
	 * 
	 * @param username
	 * @param room
	 * @param hotelNumber
	 * @param location
	 * @param hotelName
	 */
	public static void checkRooms(String userName, List<RoomInformationBean> room, String hotelNumber, String location,
			String hotelName) {

		Service service = Factory.getServiceInstance();

		log.info("------------ Available rooms --------------");
		log.info("Roomtype" + "  ----  " + "Roomprice");

		for (RoomInformationBean roominfo : room) {
			log.info(roominfo.getRoomType() + "    ----    " + roominfo.getPrice());

		}

		log.info("-----------Select Room Type Requried-------------");
		log.info("1.Single(Allows Two Members in Single Room)");
		log.info("2.Double(Aloows Four Members in Double Room)");
		log.info("3.back");

		log.info("select your choice (1 or 2 or3)");
		String choice1 = scanner.nextLine();
		while (!service.choiceVerify(choice1)) {
			log.error("select valid  choice (1 or 2 or3)");
			choice1 = scanner.nextLine();

		}

		int choice = Integer.parseInt(choice1);

		M: switch (choice) {
		case 1:
			String roomType1 = "Single";
			double price = 0;
			List<RoomInformationBean> list1 = service.roomForBooking(roomType1, hotelNumber, location);

			try {
				if (list1.isEmpty()) {
					throw new RoomNotFoundException();
				} else {
					for (RoomInformationBean roominfo : list1) {
						price = roominfo.getPrice();
					}
					startBooking(userName, roomType1, hotelName, price);
				}
			} catch (RoomNotFoundException e) {
				log.error(e.requriedMessage());
			}

			break;

		case 2:
			String roomType2 = "Double";
			double price1 = 0;
			List<RoomInformationBean> list2 = service.roomForBooking(roomType2, hotelNumber, location);

			try {
				if (list2.isEmpty()) {
					throw new RoomNotFoundException();
				} else {
					for (RoomInformationBean roominfo : list2) {
						price1 = roominfo.getPrice();
					}
					startBooking(userName, roomType2, hotelName, price1);
				}
			} catch (RoomNotFoundException e) {
				log.error(e.requriedMessage());
			}

			break;

		case 3:
			break M;
		default:
			log.info("select valid  choice (1 or 2 or3)");
			break;
		}

	}

	/**
	 * After selecting room customer will move to booking
	 * 
	 * they should provide some basic information to book hotel like chechin
	 * date,checkout date etc
	 * 
	 * @param username
	 * @param roomtype
	 * @param hotelName
	 * @param price
	 */

	public static void startBooking(String userName, String roomType, String hotelName, double price) {
		Service service = Factory.getServiceInstance();

		BookingInformationBean bookinginfo = Factory.getBookingInformationInstance();

		log.info("Please enter your requrid details to book hotel");
		log.info("Enter name of the person for whom you are booking (First and Last name only letters)");

		String name = scanner.nextLine();
		while (!service.nameVerify(name)) {
			log.error("Enter valid name (First and Last name only letters)");
			name = scanner.nextLine();
		}

		log.info("Enter phone number (It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
		String phoneNumber = scanner.nextLine();
		while (!service.phoneNumber(phoneNumber)) {
			log.error("Enter phone number (It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
			phoneNumber = scanner.nextLine();
		}
		long phoneNumbers = Long.parseLong(phoneNumber);
		LocalDate checkIn = null;
		boolean check = true;
		boolean check1 = true;
		while (check) {

			log.info("Enter chech-in date (yyyy-mm-dd))");
			String dateIn = scanner.nextLine();
			while (!service.dateVerify(dateIn)) {
				log.error("Please enter vaild date (yyyy-mm-dd)");
				dateIn = scanner.nextLine();
			}
			try {
				checkIn = LocalDate.parse(dateIn);
				while (checkIn.isBefore(LocalDate.now())) {
					log.info("Check-in date should be present date or future date");
					dateIn = scanner.nextLine();
					while (!service.dateVerify(dateIn)) {
						log.error("Enter valid date");
					}

					checkIn = LocalDate.parse(dateIn);
				}
				check = false;

			} catch (DateTimeParseException e) {
				log.error("Entered date is not present in the calender enter valid date like(yyyy-mm-dd)");
				check = true;

			}

		}

		LocalDate checkOut = null;
		while (check1) {

			log.info("Enter check-out date (yyyy-mm-dd)");
			String dateOut = scanner.nextLine();
			while (!service.dateVerify(dateOut)) {
				log.error("Please enter vaild date(yyyy-mm-dd)");
				dateOut = scanner.nextLine();
			}
			try {
				checkOut = LocalDate.parse(dateOut);
				while (checkOut.isBefore(checkIn)) {
					log.info("Check-out date should be check-in or future date");
					dateOut = scanner.nextLine();
					while (!service.dateVerify(dateOut)) {

						log.error("Enter valid date");
						checkOut = LocalDate.parse(dateOut);
					}
				}
				check1 = false;
			} catch (DateTimeParseException e) {
				log.error("Entered date is not present in the calender enter valid date like(yyyy-mm-dd)");
				check1 = true;

			}

		}

		log.info("select payment details");
		log.info("1.Online");
		log.info("2.Pay-at-Hotel");
		log.info("select choice 1 or 2");
		String choice1 = scanner.nextLine();
		while (!service.choiceVerify(choice1)) {
			log.error("select choice 1 or 2");
			choice1 = scanner.nextLine();
		}
		int choice = Integer.parseInt(choice1);
		switch (choice) {
		case 1:
			String payment = "online";
			bookinginfo.setPaymentMode(payment);
			break;
		case 2:
			String payment1 = "Pay-at-Hotel";
			bookinginfo.setPaymentMode(payment1);
			break;
		default:
			log.info("select choice 1 or 2");
			break;
		}

		bookinginfo.setBookingUserName(userName);
		bookinginfo.setBookingName(name);
		bookinginfo.setBookingNumber(phoneNumbers);
		bookinginfo.setBookingHotel(hotelName);
		bookinginfo.setBookingRoomType(roomType);
		bookinginfo.setBookingPrice(price);
		bookinginfo.setBookingDate(LocalDate.now());
		bookinginfo.setChechInDate(checkIn);
		bookinginfo.setCheckOutDate(checkOut);

		boolean check2 = service.bookingDetails(bookinginfo);
		if (check2) {
			log.info("booking sucessfull");
			log.info(bookinginfo.toString());

		} else {
			log.error("Booking Failed");
		}

	}

}
