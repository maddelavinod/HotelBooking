package com.capgemini.hotelmanagementapplication.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.factory.Factory;

/**
 * This class contains the booking data of customer who booked there hotels
 * 
 * @author vinod
 *
 */
public class BookingInformationRepository {

	static List<BookingInformationBean> booking = new ArrayList<BookingInformationBean>();

	public List<BookingInformationBean> getBookingInformationList() {

		BookingInformationBean bookinginr = Factory.getBookingInformationInstance();
		bookinginr.setBookingName("vinod c");
		bookinginr.setBookingUserName("vinod");
		bookinginr.setBookingHotel("Green View");
		bookinginr.setBookingNumber(9493115665l);
		bookinginr.setBookingRoomType("Single");

		bookinginr.setBookingPrice(10000);
		bookinginr.setBookingDate(LocalDate.of(2020, 05, 06));
		bookinginr.setChechInDate(LocalDate.of(2020, 05, 10));
		bookinginr.setCheckOutDate(LocalDate.of(2020, 05, 11));
		bookinginr.setPaymentMode("Online");

		BookingInformationBean bookinginr1 = Factory.getBookingInformationInstance();
		bookinginr1.setBookingName("chandra d");
		bookinginr1.setBookingUserName("vinod1730");
		bookinginr1.setBookingHotel("Green View");
		bookinginr1.setBookingNumber(9493115663l);
		bookinginr1.setBookingRoomType("Double");

		bookinginr1.setBookingPrice(20000);
		bookinginr1.setBookingDate(LocalDate.of(2020, 05, 10));
		bookinginr1.setChechInDate(LocalDate.of(2020, 05, 10));
		bookinginr1.setCheckOutDate(LocalDate.of(2020, 05, 19));
		bookinginr1.setPaymentMode("Online");

		BookingInformationBean bookinginr2 = Factory.getBookingInformationInstance();
		bookinginr2.setBookingName("maddela m");
		bookinginr2.setBookingUserName("vinod");
		bookinginr2.setBookingHotel("Royal Palace");
		bookinginr2.setBookingNumber(9493112665l);
		bookinginr2.setBookingRoomType("Double");

		bookinginr2.setBookingPrice(20000);
		bookinginr2.setBookingDate(LocalDate.of(2020, 05, 06));
		bookinginr2.setChechInDate(LocalDate.of(2020, 05, 28));
		bookinginr2.setCheckOutDate(LocalDate.of(2020, 05, 29));
		bookinginr2.setPaymentMode("Online");

		BookingInformationBean bookinginr3 = Factory.getBookingInformationInstance();
		bookinginr3.setBookingName("prathap m");
		bookinginr3.setBookingUserName("vinod1730");
		bookinginr3.setBookingHotel("Royal Palace");
		bookinginr3.setBookingNumber(9493112665l);
		bookinginr3.setBookingRoomType("Single");

		bookinginr3.setBookingPrice(10000);
		bookinginr3.setBookingDate(LocalDate.of(2020, 05, 06));
		bookinginr3.setChechInDate(LocalDate.of(2020, 05, 22));
		bookinginr3.setCheckOutDate(LocalDate.of(2020, 05, 29));
		bookinginr3.setPaymentMode("Online");

		booking.add(bookinginr);
		booking.add(bookinginr1);
		booking.add(bookinginr2);
		booking.add(bookinginr3);

		return booking;

	}

}
