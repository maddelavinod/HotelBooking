package com.capgemini.hotelmanagementapplication.exception;

/**
 * This is a custom exception created by the programmer when he created his own
 * exceptions
 *
 */

public class RoomNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 3699419462596816607L;
	String message = "Room not found";

	/**
	 * this method return message when ever exception called
	 * 
	 * @return message
	 */

	public String requriedMessage() {
		return message;

	}

}
