package com.capgemini.hotelmanagementapplication.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;

/**
 * This is an Interface having abstarct methods
 */
public interface Service {

	public boolean choiceVerify(String choice);

	public boolean loginDetails(String userName, String password);

	public boolean userName(String userName);

	public boolean nameVerify(String name);

	public boolean phoneNumber(String phoneNumber);

	public boolean mailId(String mail);

	public boolean password(String password);

	public boolean addCustomer(String userName, String name, String mail, long phoneNumber, String password);

	public boolean createPassword(String userName);

	public boolean updatePassword(String userName, String password);

	public List<HotelInformationBean> getHotel(String location);

	public List<BookingInformationBean> checkBooking(String userName);

	public List<RoomInformationBean> checkRooms(String location, String hotelNumber);

	public List<RoomInformationBean> roomForBooking(String roomTpye, String hotelNumber, String location);

	public boolean dateVerify(String date);

	public boolean bookingDetails(BookingInformationBean bookinginfo);

	public boolean employeeLoginDetails(String userName, String password);

	public List<CustomerInformationBean> getAllCustomers();

	public boolean checkUserNameForRegistration(String userName);

	public boolean adminLoginDetails(String userName, String password) throws IOException;

	public boolean checkLocation(String location);

	public boolean checkHotelNumber(String hotelNumber, String location);

	public boolean hotelNumberVerify(String hotelNumber);

	public boolean addHotel(String hotelName, String location, String hotelNumber, String mail, long phoneNumber);

	public boolean deleteHotel(String hotelNumber, String location);

	public boolean updateHotel(String hotelNumber, String location);

	public boolean updateForHotel(String hotelNumber, String location, String hotelName, String mail, long phoneNumber);

	public List<HotelInformationBean> getAllHotels();

	public List<HotelInformationBean> checkRoom(String location, String hotelNumber);

	public boolean priceVerify(String price);

	public boolean addRoomInformation(String location, String hotelName, String hotelNumber, String roomType,
			double price);

	public boolean deleteRoom(String location, String hotelNumber, String roomType);

	public boolean updateRoom(String location, String hotelNumber,String hotelName, String roomType, double price);

	public List<RoomInformationBean> getAllRoom();

	public boolean checkUserNameForEmployee(String userName);

	public boolean salaryVerify(String salary);

	public boolean addEmployee(String userName, String name, String mail, long phoneNumber, String password,
			int salary);

	public List<EmployeeInformationBean> getAllEmployees();

	public boolean employeeDelete(String userName);

	public boolean checkEmployeeUpdate(String userName);

	public boolean updateEmployee(String userName, String name, String mail, long phoneNumber, String password,
			int salary);

	public List<BookingInformationBean> getGuestList(String hotelName);

	public List<BookingInformationBean> getDateRequried(LocalDate date);

}
