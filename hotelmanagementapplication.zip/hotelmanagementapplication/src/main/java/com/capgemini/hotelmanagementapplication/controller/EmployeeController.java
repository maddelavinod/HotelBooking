package com.capgemini.hotelmanagementapplication.controller;

import java.util.List;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagementapplication.exception.InvalidLoginDetailsException;
import com.capgemini.hotelmanagementapplication.exception.RegistrationFailedException;
import com.capgemini.hotelmanagementapplication.factory.Factory;
import com.capgemini.hotelmanagementapplication.service.Service;

/**
 * This class is a controller of employee module employee can book a hotel to
 * customer and he can see the customers who are present in the application
 * 
 * @author vinod
 *
 */

public class EmployeeController {

	static Scanner scanner = new Scanner(System.in);

	static final Logger log = Logger.getLogger(EmployeeController.class);
	static Service service = Factory.getServiceInstance();

	private EmployeeController() {

	}

	public static void operateEmployee() {

		log.info("Welcome TO  Employee Module");
		log.info("Please Select the choice");

		L: do {
			log.info("1.Login");
			log.info("2.Exit to Home Page");

			log.info("Select the choice 1 or 2");
			String choice1 = scanner.nextLine();
			while (!service.choiceVerify(choice1)) {
				log.error("Select the choice 1 or 2");
				choice1 = scanner.nextLine();
			}
			int choice = Integer.parseInt(choice1);
			switch (choice) {
			case 1:
				log.info(
						"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
				String userName = scanner.nextLine();
				while (!service.userName(userName)) {

					log.error(
							"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
					userName = scanner.nextLine();

				}
				log.info(
						"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,and specialcharacter(6-20)");
				String password = scanner.nextLine();
				while (!service.password(password)) {
					log.error(
							"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,and specialcharacter(6-20)");
					password = scanner.nextLine();
				}
				boolean check = service.employeeLoginDetails(userName, password);
				try {
					if (check) {
						log.info("login sucessfull");
						employeeOperation(userName);

					} else {
						throw new InvalidLoginDetailsException();
					}
				} catch (InvalidLoginDetailsException exception) {
					log.error(exception.requriedMessage());
				}
				break;
			case 2:
				break L;
			default:
				log.info("Select the choice 1 or 2");
				break;
			}

		} while (true);
	}

	/**
	 * This method will show the operations that an employee acn do
	 * 
	 * @param username
	 */

	public static void employeeOperation(String username) {
		L: do {
			log.info("Select requried operation");
			log.info("1.BookHotel");
			log.info("2.CustomerDetails");
			log.info("3.Logout");
			log.info("Select your choice 1 or 2 or 3");
			String choice1 = scanner.nextLine();
			while (!service.choiceVerify(choice1)) {
				log.error("Select your choice 1 or 2 or 3");
				choice1 = scanner.nextLine();
			}
			int choice = Integer.parseInt(choice1);
			switch (choice) {
			case 1:
				CustomerController.checkLocation(username);
				break;
			case 2:
				getCustomerDetails();
				break;
			case 3:
				break L;

			default:
				log.info("Select your choice 1 or 2 or 3");
				break;
			}

		} while (true);

	}

	public static void getCustomerDetails() {
		List<CustomerInformationBean> list = service.getAllCustomers();
		for (CustomerInformationBean customerinfo : list) {
			if (list.isEmpty()) {
				log.error("Customers are not registered");
			} else {
				log.info(customerinfo);
			}
		}

	}

	/**
	 * this method will show the crud operation of employee like add update delete
	 */

	public static void employeeCrudOperation() {
		L: do {
			log.info("Select the operation you requried");
			log.info("1.add employee");
			log.info("2.delete employee");
			log.info("3.update employee");
			log.info("4.Get all employees");
			log.info("5.back");
			log.info("Select your option 1 or 2 or 3 or 4");
			String choice1 = scanner.nextLine();
			while (!service.choiceVerify(choice1)) {
				log.error("Select your option 1 or 2 or 3 or 4");
				choice1 = scanner.nextLine();

			}
			int choice = Integer.parseInt(choice1);
			switch (choice) {
			case 1:
				addEmployee();
				break;
			case 2:
				deleteEmployee();
				break;
			case 3:
				updateEmployee();
				break;
			case 4:
				getEmployeeDetails();
				break;
			case 5:
				break L;
			default:
				log.info("Select your option 1 or 2 or 3 or 4");
				break;
			}
		} while (true);
	}

	/**
	 * This method is performed by admin This method is used to add employee by
	 * taking requried details
	 * 
	 */

	public static void addEmployee() {

		log.info("Please Enter details of customer");
		log.info(
				"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
		String userName = scanner.nextLine();
		while (service.checkUserNameForEmployee(userName)) {
			log.info("username already exists please try new username");
			userName = scanner.nextLine();
		}
		while (!service.userName(userName)) {

			log.error(
					"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
			userName = scanner.nextLine();

		}

		log.info("Enter your name like firstname and lastname (should be only letters)");
		String name = scanner.nextLine();

		while (!service.nameVerify(name)) {
			log.error("Enter your name like firstname and lastname (should be only letters)");
			name = scanner.nextLine();

		}

		log.info("Enter mailid (abc@abc.abc");
		String mail = scanner.nextLine();
		while (!service.mailId(mail)) {

			log.error("Enter your name like firstname and lastname (should be only letters)");
			mail = scanner.nextLine();

		}
		log.info("Enter your phone number(It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
		String phoneNumber = scanner.nextLine();
		while (!service.phoneNumber(phoneNumber)) {
			log.error("Enter your phone number(It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
			phoneNumber = scanner.nextLine();

		}
		long phoneNumbers = Long.parseLong(phoneNumber);
		log.info(
				"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
						+ "and specialcharacter(6-20)");
		String password = scanner.nextLine();
		while (!service.password(password)) {
			log.error(
					"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
							+ "and specialcharacter(6-20)");
			password = scanner.nextLine();

		}
		log.info("Enter Employee salary(it should have 4-5 digits)");
		String salary = scanner.nextLine();
		while (!service.salaryVerify(salary)) {
			log.error("Enter Employee salary(it should have 4-5 digits)");
			salary = scanner.nextLine();

		}
		int salarys = Integer.parseInt(salary);

		boolean employee = service.addEmployee(userName, name, mail, phoneNumbers, password, salarys);
		try {
			if (employee) {
				log.info("Registration sucessfull");
			} else {
				throw new RegistrationFailedException();
			}
		} catch (RegistrationFailedException e) {
			log.error(e.requriedMessage());
		}

	}

	/**
	 * This method will givw the list of employees present in the application
	 */

	public static void getEmployeeDetails() {
		List<EmployeeInformationBean> list = service.getAllEmployees();
		for (EmployeeInformationBean employeeinfo : list) {

			if (list.isEmpty()) {
				log.error("Empoyees are not registered");
			} else {
				log.info(employeeinfo);
			}
		}

	}

	/**
	 * This method is used when you want to delete a employee from the application
	 */

	public static void deleteEmployee() {
		log.info("Enter user name");
		String userName = scanner.nextLine();
		boolean emp = service.employeeDelete(userName);
		if (emp) {
			log.info("Employee deleted");
		} else {
			log.error("Employee not deleted");
		}
	}

	/**
	 * This method is used to update the employee details when ever requried
	 */

	public static void updateEmployee() {
		log.info("Enter user name");
		String userName = scanner.nextLine();
		boolean empl = service.checkEmployeeUpdate(userName);
		if (empl) {
			log.info("Update employee");
			employeeUpdate(userName);
		} else {
			log.error("username not found");
		}

	}

	public static void employeeUpdate(String userName) {

		log.info("Enter your name like firstname and lastname (should be only letters)");
		String name = scanner.nextLine();

		while (!service.nameVerify(name)) {
			log.error("Enter your name like firstname and lastname (should be only letters)");
			name = scanner.nextLine();

		}

		log.info("Enter mailid (abc@abc.abc");
		String mail = scanner.nextLine();
		while (!service.mailId(mail)) {

			log.error("Enter your name like firstname and lastname (should be only letters)");
			mail = scanner.nextLine();

		}
		log.info("Enter your phone number(It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
		String phoneNumber = scanner.nextLine();
		while (!service.phoneNumber(phoneNumber)) {
			log.error("Enter your phone number(It should contains 10 numbers and start with 6 or 7 or 8 or 9)");
			phoneNumber = scanner.nextLine();

		}
		long phoneNumbers = Long.parseLong(phoneNumber);
		log.info(
				"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
						+ "and specialcharacter(6-20)");
		String password = scanner.nextLine();
		while (!service.password(password)) {
			log.error(
					"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
							+ "and specialcharacter(6-20)");
			password = scanner.nextLine();

		}
		log.info("Enter Employee salary(it should have 4-5 digits)");
		String salary = scanner.nextLine();
		while (!service.salaryVerify(salary)) {
			log.error("Enter Employee salary(it should have 4-5 digits)");
			salary = scanner.nextLine();

		}
		int salarys = Integer.parseInt(salary);
		boolean employe = service.updateEmployee(userName, name, mail, phoneNumbers, password, salarys);
		if (employe) {
			log.info("update sucessfull");
		} else {
			log.error("update failed");
		}

	}

}
