package com.capgemini.hotelmanagementapplication.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.factory.Factory;

/**
 * This class contains the data of customer who registred to application
 * 
 * @author vinod
 *
 */
public class CustomerInformationRepository {
	static List<CustomerInformationBean> customer = new ArrayList<CustomerInformationBean>();

	public List<CustomerInformationBean> getCustomerInformationList() {

		CustomerInformationBean customerregistration = Factory.getCustomerInformationInstance();
		customerregistration.setUserName("vinod");
		customerregistration.setName("vinod m");
		customerregistration.setMailId("vinod@gmail.com");
		customerregistration.setPhoneNumber(9493115665l);
		customerregistration.setPassword("Vinod@123");
		customer.add(customerregistration);

		CustomerInformationBean customerregistration1 = Factory.getCustomerInformationInstance();
		customerregistration1.setUserName("vinod1730");
		customerregistration1.setName("vinod maddela");
		customerregistration1.setMailId("vinodmaddela@gmail.com");
		customerregistration1.setPhoneNumber(9494307603l);
		customerregistration1.setPassword("Vinod@1234");
		customer.add(customerregistration1);

		return customer;

	}

}
