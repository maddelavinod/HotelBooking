package com.capgemini.hotelmanagementapplication.exception;

/**
 * This is a custom exception created by the programmer when he created his own
 * exceptions
 *
 */

public class HotelLocationNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -3494972983382587901L;
	String message = "Hotel not found in the given location";

	/**
	 * this method return message when ever exception called
	 * 
	 * @return message
	 */

	public String requriedMessage() {
		return message;

	}

}
