package com.capgemini.hotelmanagementapplication.bean;

import java.io.Serializable;

public class HotelInformationBean implements Serializable {

	private static final long serialVersionUID = -3473239208475100038L;

	private String hotelNumber;

	private String hotelName;

	private String location;

	private String mailId;

	private long phoneNumber;

	public HotelInformationBean() {

	}

	/**
	 * This Method Is Used Get HoteNumber
	 * 
	 * @return hotelnumber
	 */

	public String getHotelNumber() {
		return hotelNumber;
	}

	/**
	 * This Method Is Used Set HoteNumber
	 * 
	 * @param hotelNumber
	 */

	public void setHotelNumber(String hotelNumber) {
		this.hotelNumber = hotelNumber;
	}

	/**
	 * This Method Is Used Get HoteName
	 * 
	 * @return hotelname
	 */

	public String getHotelName() {
		return hotelName;
	}

	/**
	 * This Method Is Used Set HoteName
	 * 
	 * @param hotelName
	 */

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	/**
	 * This Method Is Used Get Location
	 * 
	 * @return location
	 */

	public String getLocation() {
		return location;
	}

	/**
	 * This Method Is Used Set Location
	 * 
	 * @param Location
	 */

	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * This Method Is Used Get MailId
	 * 
	 * @return mailid
	 */

	public String getMailId() {
		return mailId;
	}

	/**
	 * This Method Is Used Set HoteNumber
	 * 
	 * @param Mailid
	 */

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	/**
	 * This Method Is Used Get PhoneNumber
	 * 
	 * @return phonenumber
	 */

	public long getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * This Method Is Used Get Phonenumber
	 * 
	 * @param Phonenumber
	 */

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hotelName == null) ? 0 : hotelName.hashCode());
		result = prime * result + ((hotelNumber == null) ? 0 : hotelNumber.hashCode());
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((mailId == null) ? 0 : mailId.hashCode());
		result = prime * result + (int) (phoneNumber ^ (phoneNumber >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HotelInformationBean other = (HotelInformationBean) obj;
		if (hotelName == null) {
			if (other.hotelName != null)
				return false;
		} else if (!hotelName.equals(other.hotelName))
			return false;
		if (hotelNumber == null) {
			if (other.hotelNumber != null)
				return false;
		} else if (!hotelNumber.equals(other.hotelNumber))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (mailId == null) {
			if (other.mailId != null)
				return false;
		} else if (!mailId.equals(other.mailId))
			return false;
		if (phoneNumber != other.phoneNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return " HotelNumber=" + hotelNumber + "\n HotelName=" + hotelName + "\n Location=" + location + "\n Mailid="
				+ mailId + "\n Phonenumber=" + phoneNumber + "\n";
	}

}
