package com.capgemini.hotelmanagementapplication.dao;

import java.io.FileInputStream;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;
import com.capgemini.hotelmanagementapplication.factory.Factory;
import com.capgemini.hotelmanagementapplication.repository.BookingInformationRepository;
import com.capgemini.hotelmanagementapplication.repository.CustomerInformationRepository;
import com.capgemini.hotelmanagementapplication.repository.EmployeeInformationRepository;
import com.capgemini.hotelmanagementapplication.repository.HotelInformationRepository;
import com.capgemini.hotelmanagementapplication.repository.RoomInformationRepository;

/**
 * This is an implementation of dao interface and its methods
 * 
 * @author vinod
 *
 */

public class DaoImpl implements Dao {

	static List<CustomerInformationBean> customers = new CustomerInformationRepository().getCustomerInformationList();
	static List<HotelInformationBean> hotelList = new HotelInformationRepository().getHotelInformationList();
	static List<BookingInformationBean> booking = new BookingInformationRepository().getBookingInformationList();
	static List<RoomInformationBean> room = new RoomInformationRepository().getRoomInformationList();
	static List<EmployeeInformationBean> employeeList = new EmployeeInformationRepository()
			.getEmployeeInformationList();

	Properties properties = new Properties();

	/**
	 * This method is used to check whether th details given by the customer valid
	 * or not
	 * 
	 * @return true when details matched
	 * 
	 * @return false when details not matched
	 * 
	 * @param username
	 * 
	 * @param password
	 */

	@Override
	public boolean login(String userName, String password) {
		int check = 0;
		for (CustomerInformationBean customerinformation : customers) {
			if (customerinformation.getUserName().equals(userName)
					&& customerinformation.getPassword().equals(password)) {
				check++;
			}
		}
		return check == 0 ? false : true;
	}

	/**
	 * This method is used to add details of customer
	 * 
	 * @param username,name,mail,phonenumber,password
	 * 
	 * @return true when details added
	 * 
	 * @return false when details not added
	 */

	@Override
	public boolean addDetails(String userName, String name, String mail, long phoneNumber, String password) {
		CustomerInformationBean customerinfo = Factory.getCustomerInformationInstance();
		ArrayList<CustomerInformationBean> customer = new ArrayList<CustomerInformationBean>();

		customerinfo.setUserName(userName);
		customerinfo.setName(name);
		customerinfo.setMailId(mail);
		customerinfo.setPhoneNumber(phoneNumber);
		customerinfo.setPassword(password);
		customer.add(customerinfo);
		if (customer.isEmpty()) {
			return false;
		} else {
			customers.addAll(customer);
			return true;
		}
	}

	/**
	 * this method is used to check the username when the customer forgets his
	 * password
	 * 
	 * @param username
	 * 
	 * @return true username found
	 * 
	 * @return false ysername not found
	 */

	@Override
	public boolean createPassword(String userName) {
		int check = 0;
		for (CustomerInformationBean customerinformation : customers) {
			if (customerinformation.getUserName().equals(userName)) {
				check++;
			}

		}
		return check == 0 ? false : true;
	}

	/**
	 * This method is used to update password when customer matches his username
	 * 
	 * @param username,password
	 * 
	 * @return true when password updated
	 * 
	 * @return false when password not updated
	 */

	@Override
	public boolean updatePassword(String userName, String newPassword) {

		int check = 0;
		for (CustomerInformationBean customerinformation : customers) {
			if (customerinformation.getUserName().equals(userName)) {

				check++;
				customerinformation.setPassword(newPassword);
			}

		}
		return check == 0 ? false : true;

	}

	/**
	 * This method is used to get the hotel present in the location
	 * 
	 * @return list
	 * 
	 * @param location
	 */

	@Override
	public List<HotelInformationBean> getHotelLocation(String location) {

		ArrayList<HotelInformationBean> list = new ArrayList<HotelInformationBean>();

		for (HotelInformationBean hotelInfo : hotelList) {
			if (hotelInfo.getLocation().equals(location)) {

				list.add(hotelInfo);
			}
		}

		return list;

	}

	/**
	 * This method is used to get the booking done by specific user
	 * 
	 * @param username
	 * 
	 * @return list
	 */

	@Override
	public List<BookingInformationBean> checkCustomerBooking(String userName) {

		ArrayList<BookingInformationBean> list = new ArrayList<BookingInformationBean>();

		for (BookingInformationBean bookinginfo : booking) {
			if (bookinginfo.getBookingUserName().equals(userName)) {

				list.add(bookinginfo);

			}
		}

		return list;

	}

	/**
	 * This method is used to return the list of hotel present
	 * 
	 * @param location,hotelnumber
	 * 
	 * @return list
	 */

	@Override
	public List<RoomInformationBean> getRoomForBooking(String location, String hotelNumber) {

		ArrayList<RoomInformationBean> list = new ArrayList<RoomInformationBean>();

		for (RoomInformationBean roominfo : room) {
			if (roominfo.getHotelNumber().equals(hotelNumber) && roominfo.getHotelLocation().equals(location)) {

				list.add(roominfo);

			}
		}

		return list;

	}

	/**
	 * This method is used to return the list of hotel present
	 * 
	 * @param roomtype,hotelnumber,location
	 * 
	 * @return list
	 */

	@Override
	public List<RoomInformationBean> checkRoomForBooking(String roomTpye, String hotelNumber, String location) {

		ArrayList<RoomInformationBean> list = new ArrayList<RoomInformationBean>();
		for (RoomInformationBean roominformationbean : room) {
			if (roominformationbean.getRoomType().equals(roomTpye)
					&& roominformationbean.getHotelNumber().equals(hotelNumber)
					&& roominformationbean.getHotelLocation().equals(location)) {

				list.add(roominformationbean);
			}
		}

		return list;

	}

	/**
	 * This method is used to add booking details
	 */
	@Override
	public boolean addBooking(BookingInformationBean bookinginfo) {
		ArrayList<BookingInformationBean> book = new ArrayList<BookingInformationBean>();
		book.add(bookinginfo);
		if (book.isEmpty()) {
			return false;
		} else {
			booking.addAll(book);
			return true;

		}
	}

	/**
	 * This method is used to check details of employee
	 * 
	 * @param username,password
	 * 
	 * @return true when details matched
	 * 
	 * @return false when details not matched
	 */

	@Override
	public boolean employeeLoginDetails(String userName, String password) {
		int check = 0;
		for (EmployeeInformationBean employeeinfo : employeeList) {
			if (employeeinfo.getUsername().equals(userName) && employeeinfo.getPassword().equals(password)) {
				check++;
			}
		}
		return check == 0 ? false : true;
	}

	/**
	 * This method will get the list of customes present
	 * 
	 * @return list
	 * 
	 * @return null
	 */

	@Override
	public List<CustomerInformationBean> getCustomers() {

		return customers;

	}

	/**
	 * This method will check the details of admin matched or not
	 * 
	 * @return true when details matched
	 * 
	 * @return false when details not matched
	 */

	@Override
	public boolean adminLoginDetails(String userName, String password1) throws IOException {
		int count = 0;
		FileInputStream fileinput = new FileInputStream("db.properties");
		properties.load(fileinput);

		if (properties.getProperty("username").equals(userName)
				&& properties.getProperty("password").equals(password1)) {
			count++;

		}
		return count == 0 ? false : true;
	}

	/**
	 * this method will check the username of customer already present or not
	 * 
	 * @param user name
	 * @return true if username matches
	 * 
	 * @return false if username doesnot matches
	 */

	@Override
	public boolean checkUniqueUsernameForCustomer(String userName) {
		int count = 0;
		for (CustomerInformationBean customerinfo : customers) {
			if (customerinfo.getUserName().equals(userName)) {
				count++;
			}
		}
		return count == 0 ? false : true;

	}

	/**
	 * This method will check location to add hotel in the respective location
	 * 
	 * @param location
	 * 
	 * @return true if location matched
	 * 
	 * @return false if location not matched
	 */

	@Override
	public boolean checkLocationForHotel(String location) {

		int count = 0;
		for (HotelInformationBean hotelinfo : hotelList) {
			if (hotelinfo.getLocation().equals(location)) {
				count++;
			}
		}
		return count == 0 ? false : true;
	}

	/**
	 * This method is used to check the hotel number already present or not
	 * 
	 * @param hotelnumber,location
	 * 
	 * @return true if matched
	 * 
	 * @return false if not matched
	 */

	@Override
	public boolean checkUniqueHotelNumber(String hotelNumber, String location) {
		int count = 0;
		for (HotelInformationBean hotelinfo : hotelList) {
			if (hotelinfo.getLocation().equals(location) && hotelinfo.getHotelNumber().equals(hotelNumber)) {
				count++;
			}
		}

		return count == 0 ? false : true;
	}

	/**
	 * This method will add the hotel details into the list of hotel data
	 * 
	 * @return true if data added sucessfully
	 * 
	 * @return false if data not added sucessfully
	 */

	@Override
	public boolean addHotelDetails(String hotelName, String location, String hotelNumber, String mail,
			long phoneNumber) {
		HotelInformationBean hotelinfo = Factory.getHotelInformationInstance();
		ArrayList<HotelInformationBean> hotel = new ArrayList<HotelInformationBean>();
		hotelinfo.setHotelName(hotelName);
		hotelinfo.setLocation(location);
		hotelinfo.setHotelNumber(hotelNumber);
		hotelinfo.setMailId(mail);
		hotelinfo.setPhoneNumber(phoneNumber);
		hotel.add(hotelinfo);

		if (hotel.isEmpty()) {
			return false;
		} else {
			hotelList.addAll(hotel);
			return true;

		}
	}

	/**
	 * This method is used to delete the hotel from the hotel list
	 * 
	 * @return true if the hotel deleted sucessfully
	 * 
	 * @return false if the hotel is not deleted sucessfully
	 */

	@Override
	public boolean deleteHotelDetails(String hotelNumber, String location) {
		int count = 0;

		Iterator<HotelInformationBean> hotelbean = hotelList.iterator();
		while (hotelbean.hasNext()) {

			HotelInformationBean str = hotelbean.next();
			if (str.getHotelNumber().equals(hotelNumber) && str.getLocation().equals(location)) {
				count++;

				hotelbean.remove();

			}

		}
		return count == 0 ? false : true;

	}

	/**
	 * this method will update the details of the hotel in the hotel list
	 * 
	 * @return true if data updated
	 * 
	 * @return false if data is not updated
	 */

	@Override
	public boolean updateHotelDetails(String hotelNumber, String location) {
		int count = 0;
		for (HotelInformationBean hotelinfo : hotelList) {
			if (hotelinfo.getLocation().equals(location) && hotelinfo.getHotelNumber().equals(hotelNumber)) {
				count++;
			}
		}
		return count == 0 ? false : true;

	}

	@Override
	public boolean updateForHotelDetails(String hotelNumber, String location, String hotelName, String mail,
			long phoneNumber) {

		for (HotelInformationBean hotelinfo : hotelList) {
			if (hotelinfo.getLocation().equals(location) && hotelinfo.getHotelNumber().equals(hotelNumber)) {

				hotelinfo.setHotelName(hotelName);
				hotelinfo.setMailId(mail);
				hotelinfo.setPhoneNumber(phoneNumber);
				return true;
			}
		}
		return false;
	}

	/**
	 * This method will provide the hotels present in the hotellist
	 * 
	 * @return list
	 */

	@Override
	public List<HotelInformationBean> getAllHotel() {

		return hotelList;

	}

	/**
	 * This method will check the details of hotel to add room
	 * 
	 * @param location,hotelNumber
	 * 
	 * @return list if details present
	 * 
	 * @return null if details not present
	 */

	@Override
	public List<HotelInformationBean> checkRoomDetails(String location, String hotelNumber) {

		ArrayList<HotelInformationBean> list = new ArrayList<HotelInformationBean>();
		for (HotelInformationBean hotelinfo : hotelList) {
			if (hotelinfo.getHotelNumber().equals(hotelNumber) && hotelinfo.getLocation().equals(location)) {

				list.add(hotelinfo);
			}

		}

		return list;

	}

	/**
	 * this method will add the details of the room for the particular hotel in the
	 * room list
	 * 
	 * @return list
	 */

	@Override
	public boolean addRoomInformation(String location, String hotelName, String hotelNumber, String roomType,
			double price) {
		RoomInformationBean roominfo = Factory.getRoomInformationInstance();
		ArrayList<RoomInformationBean> rooms = new ArrayList<RoomInformationBean>();
		roominfo.setHotelLocation(location);
		roominfo.setHotelName(hotelName);
		roominfo.setHotelNumber(hotelNumber);
		roominfo.setRoomType(roomType);
		roominfo.setPrice(price);
		rooms.add(roominfo);
		if (rooms.isEmpty()) {
			return false;
		} else {
			room.addAll(rooms);
			return true;

		}
	}

	/**
	 * this method will delete the details of the room in the room list
	 * 
	 * @param location,hotelnumber,roomtype
	 * 
	 * @return true if data deleted
	 * 
	 * @return false if data is not deleted
	 */

	@Override
	public boolean deleteRoom(String location, String hotelNumber, String roomType) {

		int count = 0;
		Iterator<RoomInformationBean> roombean = room.iterator();
		while (roombean.hasNext()) {

			RoomInformationBean str = roombean.next();
			if (str.getHotelLocation().equals(location) && str.getHotelNumber().equals(hotelNumber)
					&& str.getRoomType().equals(roomType)) {
				count++;
				roombean.remove();

			}

		}
		return count == 0 ? false : true;

	}

	/**
	 * this method will update the details of the room in the room list
	 * 
	 * @param location,hotelnumber,roomtype,price
	 * 
	 * @return true if data updated
	 * 
	 * @return false if data not updated
	 */

	@Override
	public boolean updateRoom(String location, String hotelNumber, String hotelName, String roomType, double price) {
		int count = 0;
		for (RoomInformationBean roominfo : room) {
			if (roominfo.getHotelLocation().equals(location) && roominfo.getHotelNumber().equals(hotelNumber)) {
				count++;
				roominfo.setHotelName(hotelName);
				roominfo.setRoomType(roomType);
				roominfo.setPrice(price);
			}
		}

		return count == 0 ? false : true;
	}

	/**
	 * This method will return the list of rooms
	 * 
	 * @return list
	 */

	@Override
	public List<RoomInformationBean> getAllRooms() {

		return room;
	}

	/**
	 * this method will check the username of employee already present or not
	 * 
	 * @param user name
	 * @return true if username matches
	 * 
	 * @return false if username doesnot matches
	 */

	@Override
	public boolean checkUniqueUsernameForEmployee(String userName) {
		int count = 0;
		for (EmployeeInformationBean customerinfo : employeeList) {
			if (customerinfo.getUsername().equals(userName)) {
				count++;
			}
		}
		return count == 0 ? false : true;
	}

	/**
	 * This method will add the employee details into the list of employee data
	 * 
	 * @return true if data added sucessfully
	 * 
	 * @return false if data not added sucessfully
	 */

	@Override
	public boolean addEmployee(String userName, String name, String mail, long phonenumber, String password,
			int salary) {
		EmployeeInformationBean employeeinfo = Factory.getEmployeeInformationInstance();
		ArrayList<EmployeeInformationBean> employee = new ArrayList<EmployeeInformationBean>();
		employeeinfo.setUsername(userName);
		employeeinfo.setName(name);
		employeeinfo.setMailid(mail);
		employeeinfo.setPhonenumber(phonenumber);
		employeeinfo.setPassword(password);
		employeeinfo.setSalary(salary);
		employee.add(employeeinfo);

		if (employee.isEmpty()) {
			return false;
		} else {
			employeeList.addAll(employee);

			return true;
		}
	}

	@Override
	public List<EmployeeInformationBean> getAllEmployees() {

		return employeeList;
	}

	/**
	 * This method will delet the employee details from the list of employee data
	 * 
	 * @return true if data added sucessfully
	 * 
	 * @return false if data not added sucessfully
	 */
	@Override
	public boolean employeeDelete(String userName) {
		int count = 0;
		Iterator<EmployeeInformationBean> employeeBean = employeeList.iterator();
		while (employeeBean.hasNext()) {

			EmployeeInformationBean str = employeeBean.next();
			if (str.getUsername().equals(userName)) {
				count++;

				employeeBean.remove();

			}
		}
		return count == 0 ? false : true;
	}

	@Override
	public boolean checkEmployeeUpdate(String userName) {
		int count = 0;
		for (EmployeeInformationBean employeeinfo : employeeList) {
			if (employeeinfo.getUsername().equals(userName)) {
				count++;
			}
		}
		return count == 0 ? false : true;
	}

	/**
	 * 
	 * This method will update the hotel details into the list of employee data
	 * 
	 * @return true if data added sucessfully
	 * 
	 * @return false if data not added sucessfully
	 *
	 */

	@Override
	public boolean updateEmployee(String userName, String name, String mail, long phonenumber, String password,
			int salary) {
		for (EmployeeInformationBean employeeinfo : employeeList) {
			if (employeeinfo.getUsername().equals(userName)) {
				employeeinfo.setName(name);
				employeeinfo.setMailid(mail);
				employeeinfo.setPhonenumber(phonenumber);
				employeeinfo.setPassword(password);
				employeeinfo.setSalary(salary);
				return true;
			}
		}
		return false;
	}

	/**
	 * This method will provide the guest list of specific hotel from booking list
	 * 
	 * @param hotelname
	 * 
	 * @return list if details present
	 * 
	 * @return false if details nit present
	 */

	@Override
	public List<BookingInformationBean> getGuestList(String hotelName) {

		ArrayList<BookingInformationBean> list = new ArrayList<BookingInformationBean>();
		for (BookingInformationBean bookinginfo : booking) {
			if (bookinginfo.getBookingHotel().equals(hotelName)) {

				list.add(bookinginfo);

			}
		}

		return list;
	}

	/**
	 * This method will provide the guest list of specific date from booking list
	 * 
	 * @param LocalDate date
	 * 
	 * @return list if details present
	 * 
	 * @return false if details nit present
	 */

	@Override
	public List<BookingInformationBean> getDateRequried(LocalDate date) {

		ArrayList<BookingInformationBean> list = new ArrayList<BookingInformationBean>();
		for (BookingInformationBean bookinginfo : booking) {
			if (bookinginfo.getChechInDate().equals(date)) {

				list.add(bookinginfo);

			}
		}

		return list;
	}
}
