package com.capgemini.hotelmanagementapplication.controller;

import java.io.IOException;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;
import com.capgemini.hotelmanagementapplication.exception.BookingNotDoneException;
import com.capgemini.hotelmanagementapplication.exception.RegistrationFailedException;
import com.capgemini.hotelmanagementapplication.factory.Factory;
import com.capgemini.hotelmanagementapplication.service.Service;

public class AdminController {

	static Scanner scanner = new Scanner(System.in);

	static final Logger log = Logger.getLogger(AdminController.class);

	static Service service = Factory.getServiceInstance();

	private AdminController() {

	}

	/**
	 * this method will ask to login the admin to perform his task
	 * 
	 * @throws IOException
	 */

	public static void operateAdmin() throws IOException {

		log.info("Welcome TO  admin Module");
		log.info("Please Select the choice");

		L: do {
			log.info("1.Login");
			log.info("2.Exit to Home Page");

			log.info("Select the choice 1 or 2");
			String choiceOne = scanner.nextLine();
			while (!service.choiceVerify(choiceOne)) {
				log.error("Select the choice 1 or 2");
				choiceOne = scanner.nextLine();
			}
			int choice = Integer.parseInt(choiceOne);
			switch (choice) {
			case 1:

				log.info(
						"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
				String userName = scanner.nextLine();
				while (!service.userName(userName)) {

					log.error(
							"Enter Your username [It can contains letters, numbers,specialcharacters but length should be (3-14)])");
					userName = scanner.nextLine();
				}
				log.info(
						"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
								+ "and specialcharacter(6-20)");
				String password = scanner.nextLine();
				while (!service.password(password)) {
					log.error(
							"Enter password (It should contains atleast one letter with uppercase and lowercase, atleast one number,"
									+ "and specialcharacter(6-20)");
					password = scanner.nextLine();
				}
				boolean check = service.adminLoginDetails(userName, password);
				if (check) {
					log.info("Login sucessfull");
					adminOperation();
				} else {
					log.error("Invalid login details");
				}

				break;
			case 2:
				break L;
			default:
				log.info("Select the choice 1 or 2");
				break;

			}

		} while (true);
	}

	/**
	 * This method will display the operations can admin perform
	 * 
	 * admincan select his requried operation based on his requriment
	 */

	public static void adminOperation() {
		A: do {
			log.info("Please select which operation you need to access");
			log.info("1.operation on Hotels");
			log.info("2.Operation on Rooms");
			log.info("3.Operation on Employees");
			log.info("4.View List Of Hotels");
			log.info("5.Get All Rooms");
			log.info("6.View Guest List of Specified Hotels");
			log.info("7.View Booking At Specified Date");
			log.info("8.logout");

			log.info("Select your choice 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9");
			String choiceTwo = scanner.nextLine();
			while (!service.choiceVerify(choiceTwo)) {
				log.error("Select your choice 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9");
				choiceTwo = scanner.nextLine();

			}
			int choice = Integer.parseInt(choiceTwo);
			switch (choice) {
			case 1:
				hotelOperation();
				break;
			case 2:
				operateRoom();
				break;
			case 3:
				EmployeeController.employeeCrudOperation();

				break;
			case 4:
				getHotelDetails();
				break;
			case 5:
				getRoomDetails();
				break;

			case 6:
				guestList();
				break;
			case 7:
				specifiedDate();
				break;
			case 8:
				break A;
			default:
				log.info("Select your choice 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9");
				break;

			}
		} while (true);
	}

	/**
	 * this method takes place of the crud operation of hotel
	 * 
	 * where we can add,update,delete hotels
	 */

	public static void hotelOperation() {
		M: do {
			log.info("Select the operation requried on hotel");
			log.info("1.addhotels");
			log.info("2.delete hotels");
			log.info("3.update hotels");
			log.info("4.back");
			log.info("Select your choice 1 or 2 or 3 or 4");
			String choiceThree = scanner.nextLine();
			while (!service.choiceVerify(choiceThree)) {
				log.error("Select your choice 1 or 2 or 3 or 4");
				choiceThree = scanner.nextLine();
			}
			int choice = Integer.parseInt(choiceThree);
			switch (choice) {
			case 1:
				log.info("Select location to add hotel");
				log.info("1.chennai");
				log.info("2.vizag");
				log.info("3.back");
				log.info("selction choice 1 or 2 or 3");
				String choiceFour = scanner.nextLine();
				while (!service.choiceVerify(choiceFour)) {
					log.error("selction choice 1 or 2 or 3");
					choiceFour = scanner.nextLine();
				}
				int choiceReq = Integer.parseInt(choiceFour);
				V: switch (choiceReq) {
				case 1:

					boolean check = service.checkLocation("chennai");
					if (check) {
						addHotel("chennai");
					} else {
						log.error("Location not found");
					}
					break;
				case 2:
					boolean check2 = service.checkLocation("vizag");
					if (check2) {
						addHotel("vizag");
					} else {
						log.error("Location not found");
					}
					break;
				case 3:
					break V;
				default:
					log.info("selction choice 1 or 2 or 3");
					break;
				}

				break;
			case 2:
				log.info("Select location to delete hotel");
				log.info("1.chennai");
				log.info("2.vizag");
				log.info("3.back");
				log.info("selction choice 1 or 2 or 3");
				String choiceSix = scanner.nextLine();
				while (!service.choiceVerify(choiceSix)) {
					log.error("selction choice 1 or 2 or 3");
					choiceSix = scanner.nextLine();
				}
				int choiceReqOne = Integer.parseInt(choiceSix);
				I: switch (choiceReqOne) {
				case 1:
					List<HotelInformationBean> list1 = service.getHotel("chennai");
					if (list1.isEmpty()) {
						log.error("location not found");
					} else {
						deleteHotel(list1, "chennai");
					}
					break;
				case 2:
					List<HotelInformationBean> list2 = service.getHotel("vizag");
					if (list2.isEmpty()) {
						log.error("location not found");
					} else {
						deleteHotel(list2, "vizag");

					}
					break;
				case 3:
					break I;
				default:
					log.info("selction choice 1 or 2 or 3");
					break;

				}
				break;
			case 3:
				log.info("Select location to update hotel");
				log.info("1.chennai");
				log.info("2.vizag");
				log.info("3.back");
				log.info("selction choice 1 or 2 or 3");
				String choiceSeven = scanner.nextLine();
				while (!service.choiceVerify(choiceSeven)) {
					log.error("selction choice 1 or 2 or 3");
					choiceSeven = scanner.nextLine();
				}
				int choiceReqTwo = Integer.parseInt(choiceSeven);
				I: switch (choiceReqTwo) {
				case 1:
					List<HotelInformationBean> list1 = service.getHotel("chennai");
					if (list1.isEmpty()) {
						log.error("location not found");
					} else {
						updateHotel(list1, "chennai");
					}
					break;
				case 2:
					List<HotelInformationBean> list2 = service.getHotel("vizag");
					if (list2.isEmpty()) {
						log.error("location not found");
					} else {
						updateHotel(list2, "vizag");
					}
					break;
				case 3:
					break I;
				default:
					log.info("selction choice 1 or 2 or 3");
					break;

				}
				break;
			case 4:
				break M;
			default:
				log.info("Select your choice 1 or 2 or 3 or 4");
				break;
			}

		} while (true);
	}

	/**
	 * In this method admin can add hotel by checking location
	 * 
	 * @param location
	 */

	public static void addHotel(String location) {

		log.info("Enter Hotel number only numbers (can be single or double digits(1-99)");
		String hotelNumber = scanner.nextLine();
		while (service.checkHotelNumber(hotelNumber, location)) {
			log.error("hotel number given in this location is already exists");
			hotelNumber = scanner.nextLine();
		}
		while (!service.hotelNumberVerify(hotelNumber)) {
			log.error("Enter Hotel number only numbers (can be single or double digits(1-99)");
			hotelNumber = scanner.nextLine();

		}
		log.info("Enter hotel name it should be characters(eg: Hotel Palasa)");
		String hotelName = scanner.nextLine();
		while (!service.nameVerify(hotelName)) {
			log.error("Enter hotel name it should be characters(eg: Hotel Palasa)");
			hotelName = scanner.nextLine();
		}
		log.info("Enter hotel mail eg(abc@abc.abc)");
		String mail = scanner.nextLine();
		while (!service.mailId(mail)) {
			log.error("Enter hotel mail eg(abc@abc.abc)");
			mail = scanner.nextLine();
		}

		log.info("Enter hotel phone number[it should contains 10 digits and starts with 6 or 7 or 8 or 9]");
		String phoneNumber = scanner.nextLine();
		while (!service.phoneNumber(phoneNumber)) {
			log.error("Enter hotel phone number[it should contains 10 digits and starts with 6 or 7 or 8 or 9]");
			phoneNumber = scanner.nextLine();
		}
		Long phoneNumbers = Long.parseLong(phoneNumber);

		boolean hotel = service.addHotel(hotelName, location, hotelNumber, mail, phoneNumbers);
		try {
			if (hotel) {
				log.info("Registration Sucessfull");
			} else {
				throw new RegistrationFailedException();
			}
		} catch (RegistrationFailedException exception1) {
			log.error(exception1.requriedMessage());
		}

	}

	public static void deleteHotel(List<HotelInformationBean> hotelList, String location) {
		for (HotelInformationBean hotelinfo : hotelList) {

			log.info(hotelinfo.getHotelNumber() + "-----" + hotelinfo.getHotelName());

		}

		log.info("Enter hotel number");
		String hotelNumber = scanner.nextLine();
		boolean checked = service.deleteHotel(hotelNumber, location);

		if (checked) {
			log.info("hotel deleted sucessfully");
		} else {
			log.error("hotel was not deleted please check the hotelnumber and try again");
		}

	}

	/**
	 * This method is used to update hotel
	 * 
	 * @param hotellist
	 * @param location
	 */

	public static void updateHotel(List<HotelInformationBean> hotelList, String location) {
		for (HotelInformationBean hotelinfo : hotelList) {

			log.info(hotelinfo.getHotelNumber() + "....." + hotelinfo.getHotelName());

		}

		log.info("Enter hotel number");
		String hotelNumber = scanner.nextLine();
		boolean checks = service.updateHotel(hotelNumber, location);

		if (checks) {
			log.info("hotel details matched");
			updateForHotel(hotelNumber, location);
		} else {
			log.error("hotel was not matched please check the hotelnumber and try again");
		}

	}

	public static void updateForHotel(String hotelNumber, String location) {
		log.info("Enter hotel name it should be characters(eg: Hotel Palasa)");
		String hotelName = scanner.nextLine();
		while (!service.nameVerify(hotelName)) {
			log.error("Enter hotel name it should be characters(eg: Hotel Palasa)");
			hotelName = scanner.nextLine();
		}
		log.info("Enter hotel mail eg(abc@abc.abc)");
		String mail = scanner.nextLine();
		while (!service.mailId(mail)) {
			log.error("Enter hotel mail eg(abc@abc.abc)");
			mail = scanner.nextLine();
		}

		log.info("Enter hotel phone number[it should contains 10 digits and starts with 6 or 7 or 8 or 9]");
		String phoneNumber = scanner.nextLine();
		while (!service.phoneNumber(phoneNumber)) {
			log.error("Enter hotel phone number[it should contains 10 digits and starts with 6 or 7 or 8 or 9]");
			phoneNumber = scanner.nextLine();
		}
		Long phoneNumbers = Long.parseLong(phoneNumber);
		boolean checks = service.updateForHotel(hotelNumber, location, hotelName, mail, phoneNumbers);
		if (checks) {
			log.info("hotel update sucessfull");
		} else {
			log.error("hotel update failed");
		}
	}

	/**
	 * This method is used to get all hotels present in the list
	 * 
	 */
	public static void getHotelDetails() {

		List<HotelInformationBean> list1 = service.getAllHotels();
		for (HotelInformationBean hotelinfo : list1) {

			if (list1.isEmpty()) {
				log.error("Hotels are not added");
			} else {
				log.info(hotelinfo);
			}
		}

	}

	/**
	 * this method will used to select the requried crud operation of rooms
	 */

	public static void operateRoom() {
		M: do {
			log.info("Select the operation requried on rooms");
			log.info("1.addroom");
			log.info("2.delete room");
			log.info("3.update room");
			log.info("4.get all rooms");
			log.info("5.back");
			log.info("Select your choice 1 or 2 or 3 or 4");
			String choiceOne = scanner.nextLine();
			while (!service.choiceVerify(choiceOne)) {
				log.error("Select your choice 1 or 2 or 3 or 4");
				choiceOne = scanner.nextLine();
			}
			int choice = Integer.parseInt(choiceOne);
			switch (choice) {
			case 1:
				log.info("Select location to addroom");
				log.info("1.chennai");
				log.info("2.vizag");
				log.info("3.back");
				log.info("selction choice 1 or 2 or 3");
				String choiceTwo = scanner.nextLine();
				while (!service.choiceVerify(choiceTwo)) {
					log.info("selction choice 1 or 2 or 3");
					choiceTwo = scanner.nextLine();
				}
				int choiceReq = Integer.parseInt(choiceTwo);
				Z: switch (choiceReq) {
				case 1:
					List<HotelInformationBean> list1 = service.getHotel("chennai");
					if (list1.isEmpty()) {
						log.error("location not found");
					} else {
						addRoom(list1, "chennai");
					}
					break;
				case 2:
					List<HotelInformationBean> list2 = service.getHotel("vizag");
					if (list2.isEmpty()) {
						log.error("location not found");
					} else {
						addRoom(list2, "vizag");
					}
					break;
				case 3:
					break Z;
				default:
					log.info("selction choice 1 or 2 or 3");
					break;

				}

				break;
			case 2:
				log.info("Select location to delete room");
				log.info("1.chennai");
				log.info("2.vizag");
				log.info("3.back");
				log.info("selction choice 1 or 2 or 3");
				String choiceFour = scanner.nextLine();
				while (!service.choiceVerify(choiceFour)) {
					log.error("selction choice 1 or 2 or 3");
					choiceFour = scanner.nextLine();
				}
				int choiceReqOne = Integer.parseInt(choiceFour);
				X: switch (choiceReqOne) {
				case 1:
					List<HotelInformationBean> list1 = service.getHotel("chennai");
					if (list1.isEmpty()) {
						log.error("location not found");
					} else {
						deleteRoom(list1, "chennai");
					}
					break;
				case 2:
					List<HotelInformationBean> list2 = service.getHotel("vizag");
					if (list2.isEmpty()) {
						log.error("location not found");
					} else {
						deleteRoom(list2, "vizag");
					}
					break;
				case 3:
					break X;
				default:
					log.info("selction choice 1 or 2 or 3");
					break;

				}
				break;
			case 3:
				log.info("Select location to update room");
				log.info("1.chennai");
				log.info("2.vizag");
				log.info("3.back");
				log.info("selction choice 1 or 2 or 3");
				String choiceFive = scanner.nextLine();
				while (!service.choiceVerify(choiceFive)) {
					log.error("selction choice 1 or 2 or 3");
					choiceFive = scanner.nextLine();
				}
				int choiceReqTwo = Integer.parseInt(choiceFive);
				Y: switch (choiceReqTwo) {
				case 1:
					List<HotelInformationBean> list1 = service.getHotel("chennai");
					if (list1.isEmpty()) {
						log.error("location not found");
					} else {
						updateRoom(list1, "chennai");
					}
					break;
				case 2:
					List<HotelInformationBean> list2 = service.getHotel("vizag");
					if (list2.isEmpty()) {
						log.error("location not found");
					} else {
						updateRoom(list2, "vizag");
					}
					break;
				case 3:
					break Y;
				default:
					log.info("selction choice 1 or 2 or 3");
					break;
				}
				break;
			case 4:
				gellAllRooms();
				break;
			case 5:
				break M;
			default:
				log.info("Select your choice 1 or 2 or 3 or 4");
				break;

			}
		} while (true);

	}

	/**
	 * This method is used to check the details to add room
	 * 
	 * @param hotellist
	 * @param location
	 */

	public static void addRoom(List<HotelInformationBean> hotellist, String location) {

		for (HotelInformationBean hotelinfo : hotellist) {

			log.info(hotelinfo.getHotelNumber() + "....." + hotelinfo.getHotelName());

		}

		log.info("Enter hotel number");
		String hotelNumber = scanner.nextLine();
		String hotelName = null;
		List<HotelInformationBean> list1 = service.checkRoom(location, hotelNumber);

		List<HotelInformationBean> list2 = service.checkRoom(location, hotelNumber);
		if (list2.isEmpty()) {
			log.error("hotel details not found ");

		} else {
			log.info("hotel details found");
			for (HotelInformationBean roominfo : list1) {
				hotelName = roominfo.getHotelName();
			}

			addRoomDetails(location, hotelNumber, hotelName);
		}

	}

	/**
	 * This method is used to add room in a particular hotels when the details
	 * matched in the above method
	 * 
	 * @param location
	 * @param hotelNumber
	 * @param hotelName
	 */

	public static void addRoomDetails(String location, String hotelNumber, String hotelName) {
		RoomInformationBean roominfo = Factory.getRoomInformationInstance();
		log.info("Select room type");
		log.info("1.Single");
		log.info("2.Double");
		log.info("3.back");
		String choiceOne = scanner.nextLine();
		while (!service.choiceVerify(choiceOne)) {
			log.error("selction choice 1 or 2 or 3");
			choiceOne = scanner.nextLine();
		}
		int choice = Integer.parseInt(choiceOne);
		B: switch (choice) {
		case 1:
			String roomType = "Single";
			double price = 10000;
			roominfo.setHotelLocation(location);
			roominfo.setHotelName(hotelName);
			roominfo.setHotelNumber(hotelNumber);
			roominfo.setRoomType(roomType);
			roominfo.setPrice(price);
			boolean add1 = service.addRoomInformation(location, hotelName, hotelNumber, roomType, price);

			try {
				if (add1) {
					log.info("Registration Sucessfull");
				} else {
					throw new RegistrationFailedException();
				}
			} catch (RegistrationFailedException exception1) {
				log.error(exception1.requriedMessage());
			}
			break;
		case 2:
			String roomType2 = "Double";
			double price1 = 20000;
			roominfo.setHotelLocation(location);
			roominfo.setHotelName(hotelName);
			roominfo.setHotelNumber(hotelNumber);
			roominfo.setRoomType(roomType2);
			roominfo.setPrice(price1);
			boolean add2 = service.addRoomInformation(location, hotelName, hotelNumber, roomType2, price1);

			try {
				if (add2) {
					log.info("Registration Sucessfull");
				} else {
					throw new RegistrationFailedException();
				}
			} catch (RegistrationFailedException exception1) {
				log.error(exception1.requriedMessage());
			}
			break;
		case 3:
			break B;
		default:
			log.info("selction choice 1 or 2 or 3");
			break;

		}

	}

	/**
	 * This method is used to delete a particular room in a hotel
	 * 
	 * @param hotellist
	 * @param location
	 */
	public static void deleteRoom(List<HotelInformationBean> hotellist, String location) {
		for (HotelInformationBean hotelinfo : hotellist) {

			log.info(hotelinfo.getHotelNumber() + "....." + hotelinfo.getHotelName());

		}

		log.info("Enter hotel number");
		String hotelNumber = scanner.nextLine();
		log.info("Select room type to delete");
		log.info("1.Single");
		log.info("2.Double");
		log.info("3.back");
		String choiceThree = scanner.nextLine();
		while (!service.choiceVerify(choiceThree)) {
			log.error("selction choice 1 or 2 or 3");
			choiceThree = scanner.nextLine();
		}
		int choice = Integer.parseInt(choiceThree);
		B: switch (choice) {
		case 1:
			String roomType = "Single";
			boolean room = service.deleteRoom(location, hotelNumber, roomType);
			if (room) {
				log.info("Room deleted");
			} else {
				log.error("Room was not deleted ");
			}
			break;
		case 2:
			String roomType1 = "Double";
			boolean room1 = service.deleteRoom(location, hotelNumber, roomType1);
			if (room1) {
				log.info("Room deleted");
			} else {
				log.error("Room was not deleted ");
			}
			break;
		case 3:
			break B;
		default:
			log.info("selction choice 1 or 2 or 3");
			break;
		}

	}

	/**
	 * This method is used to update particular room ina hotel
	 * 
	 * @param hotellist
	 * @param location
	 */

	public static void updateRoom(List<HotelInformationBean> hotellist, String location) {
		for (HotelInformationBean hotelinfo : hotellist) {

			log.info(hotelinfo.getHotelNumber() + "....." + hotelinfo.getHotelName());

		}

		log.info("Enter hotel number");
		String hotelNumber = scanner.nextLine();
		String hotelName = null;
		log.info("Select room type to update");
		log.info("1.Single");
		log.info("2.Double");
		log.info("3.back");
		String choiceThree = scanner.nextLine();
		while (!service.choiceVerify(choiceThree)) {
			log.error("selction choice 1 or 2 or 3");
			choiceThree = scanner.nextLine();
		}
		int choice = Integer.parseInt(choiceThree);
		B: switch (choice) {
		case 1:
			String roomType = "Single";
			double price = 10000;
			for (HotelInformationBean hotelinfo : hotellist) {
				hotelName = hotelinfo.getHotelName();
			}
			boolean room1 = service.updateRoom(location, hotelNumber, hotelName, roomType, price);
			if (room1) {
				log.info("update sucessfull");
			} else {
				log.error("update unsucessfull ");
			}
			break;
		case 2:
			String roomType1 = "Double";
			double price1 = 20000;
			for (HotelInformationBean hotelinfo : hotellist) {
				hotelName = hotelinfo.getHotelName();
			}
			boolean room2 = service.updateRoom(location, hotelNumber, hotelName, roomType1, price1);
			if (room2) {
				log.info("update sucessfull");
			} else {
				log.error("update unsucessfull ");
			}

			break;
		case 3:
			break B;
		default:
			log.info("selction choice 1 or 2 or 3");
			break;

		}
	}

	/**
	 * This method will return all the rooms available
	 */

	public static void getRoomDetails() {

		List<RoomInformationBean> list1 = service.getAllRoom();
		for (RoomInformationBean roominfo : list1) {

			log.info(roominfo);
		}

	}

	/**
	 * this method will return guest list in a particular hotel by serching hotel
	 * name
	 */

	public static void guestList() {
		log.info("Enter hotel name");
		String hotelName = scanner.nextLine();
		List<BookingInformationBean> list = service.getGuestList(hotelName);

		try {
			if (list.isEmpty()) {
				throw new BookingNotDoneException();
			} else {
				for (BookingInformationBean booking : list) {
					log.info(booking);
				}

			}
		} catch (BookingNotDoneException e) {
			log.error(e.requriedMessage());
		}
	}

	/**
	 * this method is used to check the booking by check-in date
	 */

	public static void specifiedDate() {
		log.info("Enter the check-in date requried(yyyy-mm-dd)");
		String date = scanner.nextLine();
		while (!service.dateVerify(date)) {
			log.error("Enter the check-in date requried(yyyy-mm-dd)");
			date = scanner.nextLine();

		}
		LocalDate dates = null;
		try {

			dates = LocalDate.parse(date);
		} catch (DateTimeParseException e) {
			log.error("Entered date is not present in the calender enter valid date like(yyyy-mm-dd)");

		}
		List<BookingInformationBean> list = service.getDateRequried(dates);

		try {
			if (list.isEmpty()) {
				throw new BookingNotDoneException();
			} else {
				for (BookingInformationBean booking : list) {
					log.info(booking);
				}

			}
		} catch (BookingNotDoneException e) {
			log.error(e.requriedMessage());
		}
	}

	public static void gellAllRooms() {

		List<RoomInformationBean> list1 = service.getAllRoom();
		for (RoomInformationBean roominfo : list1) {

			if (list1.isEmpty()) {
				log.error("rooms are not added");
			} else {
				log.info(roominfo);
			}
		}

	}

}
