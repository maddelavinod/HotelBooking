package com.capgemini.hotelmanagementapplication.dao;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;

/**
 * This is an Interface of DAO which contains abstarct methods
 *
 */
public interface Dao {

	public boolean login(String userName, String password);

	public boolean addDetails(String userName, String name, String mail, long phoneNumber, String password);

	public boolean createPassword(String userName);

	public boolean updatePassword(String userName, String password);

	public List<HotelInformationBean> getHotelLocation(String location);

	public List<BookingInformationBean> checkCustomerBooking(String userName);

	public List<RoomInformationBean> getRoomForBooking(String location, String hotelNumber);

	public List<RoomInformationBean> checkRoomForBooking(String roomTpye, String hotelNumber, String location);

	public boolean addBooking(BookingInformationBean bookinginfo);

	public boolean employeeLoginDetails(String userName, String password);

	public List<CustomerInformationBean> getCustomers();

	public boolean adminLoginDetails(String userName, String password) throws IOException;

	public boolean checkUniqueUsernameForCustomer(String userName);

	public boolean checkLocationForHotel(String location);

	public boolean checkUniqueHotelNumber(String hotelNumber, String location);

	public boolean addHotelDetails(String hotelName, String location, String hotelNumber, String mail,
			long phoneNumber);

	public boolean deleteHotelDetails(String hotelNumber, String location);

	public boolean updateHotelDetails(String hotelNumber, String location);

	public boolean updateForHotelDetails(String hotelNumber, String location, String hotelName, String mail,
			long phoneNumber);

	public List<HotelInformationBean> getAllHotel();

	public List<HotelInformationBean> checkRoomDetails(String location, String hotelNumber);

	public boolean addRoomInformation(String location, String hotelName, String hotelNumber, String roomType,
			double price);

	public boolean deleteRoom(String location, String hotelNumber, String roomType);

	public boolean updateRoom(String location, String hotelNumber, String hotelName, String roomType, double price);

	public List<RoomInformationBean> getAllRooms();

	public boolean checkUniqueUsernameForEmployee(String userName);

	public boolean addEmployee(String userName, String name, String mail, long phoneNumber, String password,
			int salary);

	public List<EmployeeInformationBean> getAllEmployees();

	public boolean employeeDelete(String userName);

	public boolean checkEmployeeUpdate(String userName);

	public boolean updateEmployee(String userName, String name, String mail, long phoneNumber, String password,
			int salary);

	public List<BookingInformationBean> getGuestList(String hotelName);

	public List<BookingInformationBean> getDateRequried(LocalDate date);

}
