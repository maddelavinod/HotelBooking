package com.capgemini.hotelmanagementapplication.factory;

import com.capgemini.hotelmanagementapplication.validation.InputValidations;

import com.capgemini.hotelmanagementapplication.bean.BookingInformationBean;
import com.capgemini.hotelmanagementapplication.bean.CustomerInformationBean;
import com.capgemini.hotelmanagementapplication.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagementapplication.bean.HotelInformationBean;
import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;
import com.capgemini.hotelmanagementapplication.dao.Dao;
import com.capgemini.hotelmanagementapplication.dao.DaoImpl;
import com.capgemini.hotelmanagementapplication.service.Service;
import com.capgemini.hotelmanagementapplication.service.ServiceImpl;
import com.capgemini.hotelmanagementapplication.validation.InputValidationImpl;

/**
 * This is the class where the object of every class and interface created
 *
 * By using class name we can use the object where ever you want
 */

public class Factory {

	private Factory() {

	}

	public static InputValidations getInputValidationInstance() {
		return new InputValidationImpl();
	}

	public static Service getServiceInstance() {

		return new ServiceImpl();

	}

	public static CustomerInformationBean getCustomerInformationInstance() {
		return new CustomerInformationBean();

	}

	public static Dao getDAOInstance() {
		return new DaoImpl();

	}

	public static HotelInformationBean getHotelInformationInstance() {
		return new HotelInformationBean();

	}

	public static BookingInformationBean getBookingInformationInstance() {
		return new BookingInformationBean();

	}

	public static RoomInformationBean getRoomInformationInstance() {
		return new RoomInformationBean();

	}

	public static EmployeeInformationBean getEmployeeInformationInstance() {
		return new EmployeeInformationBean();

	}

}
