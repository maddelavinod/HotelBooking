package com.capgemini.hotelmanagementapplication.controller;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagementapplication.factory.Factory;
import com.capgemini.hotelmanagementapplication.service.Service;

/**
 * 
 * This Class Contains main method which is used to start our program
 * 
 * @author Vinod
 *
 */

public class MainController {

	static final Logger log = Logger.getLogger(MainController.class);

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		log.info("Welcome to Hotel Management Application");

		log.info("================================");

		Service service = Factory.getServiceInstance();

		L: do {
			log.info("1.Customer");
			log.info("2.Employee");
			log.info("3.Admin");
			log.info("4.Exit");

			log.info("Please Select the choice to perform operation requried");

			String choice1 = scanner.nextLine();
			while (!service.choiceVerify(choice1)) {
				log.error("Enter valid chioce [1 or 2 or 3 or 4]");
				choice1 = scanner.nextLine();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {

			case 1:
				CustomerController.operateCustomer();
				break;
			case 2:
				EmployeeController.operateEmployee();
				break;
			case 3:
				try {
					AdminController.operateAdmin();
				} catch (Exception e) {
					log.info(e.getMessage());
				}
				break;
			case 4:
				break L;
			default:
				log.info("Enter valid choice[1 or 2 or 3 or 4]");
				break;

			}

		} while (true);

		log.info("Thanks For Visting");
		scanner.close();

	}
}
