package com.capgemini.hotelmanagementapplication.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagementapplication.factory.Factory;

/**
 * This class contains the data of employee who registred to application
 * 
 * @author vinod
 *
 */
public class EmployeeInformationRepository {

	static List<EmployeeInformationBean> employeelist = new ArrayList<EmployeeInformationBean>();

	public List<EmployeeInformationBean> getEmployeeInformationList() {

		EmployeeInformationBean employeeinfo = Factory.getEmployeeInformationInstance();
		employeeinfo.setUsername("chandra");
		employeeinfo.setName("Chandra Maddela");
		employeeinfo.setPhonenumber(7386765135l);
		employeeinfo.setMailid("chandra@gmail.com");
		employeeinfo.setPassword("Chandra@123");
		employeeinfo.setSalary(15000);

		employeelist.add(employeeinfo);

		return employeelist;

	}

}
