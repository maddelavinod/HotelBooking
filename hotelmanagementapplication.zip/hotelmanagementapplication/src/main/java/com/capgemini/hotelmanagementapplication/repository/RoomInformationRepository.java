package com.capgemini.hotelmanagementapplication.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementapplication.bean.RoomInformationBean;
import com.capgemini.hotelmanagementapplication.factory.Factory;

/**
 * This class contains the data of room who added to application
 * 
 * @author vinod
 *
 */
public class RoomInformationRepository {

	static List<RoomInformationBean> room = new ArrayList<RoomInformationBean>();

	public List<RoomInformationBean> getRoomInformationList() {

		RoomInformationBean roominfo = Factory.getRoomInformationInstance();
		roominfo.setHotelNumber("2");
		roominfo.setHotelName("Green View");

		roominfo.setRoomType("Single");
		roominfo.setHotelLocation("chennai");
		roominfo.setPrice(10000);

		RoomInformationBean roominfo2 = Factory.getRoomInformationInstance();
		roominfo2.setHotelNumber("2");
		roominfo2.setHotelName("Green View");

		roominfo2.setRoomType("Double");
		roominfo2.setHotelLocation("chennai");
		roominfo2.setPrice(20000);

		RoomInformationBean roominfo4 = Factory.getRoomInformationInstance();
		roominfo4.setHotelNumber("1");
		roominfo4.setHotelName("Royal Palace");

		roominfo4.setRoomType("Single");
		roominfo4.setHotelLocation("chennai");
		roominfo4.setPrice(10000);

		RoomInformationBean roominfo6 = Factory.getRoomInformationInstance();
		roominfo6.setHotelNumber("1");
		roominfo6.setHotelName("Royal Palace");

		roominfo6.setRoomType("Double");
		roominfo6.setHotelLocation("chennai");
		roominfo6.setPrice(20000);

		RoomInformationBean roominfo8 = Factory.getRoomInformationInstance();
		roominfo8.setHotelNumber("2");
		roominfo8.setHotelName("Hotel Palasa");

		roominfo8.setRoomType("Single");
		roominfo8.setHotelLocation("vizag");
		roominfo8.setPrice(10000);

		RoomInformationBean roominfo10 = Factory.getRoomInformationInstance();
		roominfo10.setHotelNumber("2");
		roominfo10.setHotelName("Hotel Palasa");

		roominfo10.setRoomType("Double");
		roominfo10.setHotelLocation("vizag");
		roominfo10.setPrice(20000);

		RoomInformationBean roominfo12 = Factory.getRoomInformationInstance();
		roominfo12.setHotelNumber("1");
		roominfo12.setHotelName("Grand Chola");

		roominfo12.setRoomType("Single");
		roominfo12.setHotelLocation("vizag");
		roominfo12.setPrice(10000);

		RoomInformationBean roominfo14 = Factory.getRoomInformationInstance();
		roominfo14.setHotelNumber("1");
		roominfo14.setHotelName("Grand Chola");

		roominfo14.setRoomType("Double");
		roominfo14.setHotelLocation("vizag");
		roominfo14.setPrice(20000);

		room.add(roominfo);

		room.add(roominfo2);

		room.add(roominfo4);

		room.add(roominfo6);

		room.add(roominfo8);

		room.add(roominfo10);

		room.add(roominfo12);

		room.add(roominfo14);

		return room;

	}

}
